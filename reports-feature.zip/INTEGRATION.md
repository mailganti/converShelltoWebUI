# Reports Tab Integration Guide

Add a Reports tab to your existing Orchestration Dashboard for running read-only status scripts without approval.

## Quick Setup

### 1. Backend Integration

Add to your existing FastAPI app (e.g., `main.py`):

```python
from reports import router as reports_router

# Add after your other routers
app.include_router(reports_router, prefix="/api/reports", tags=["reports"])
```

Set the reports scripts directory (optional - defaults shown):
```bash
export REPORTS_SCRIPTS_DIR=/u01/app/ssaAgent/orchestration-system/scripts/reports
```

### 2. Frontend Integration

Add to your HTML (e.g., `index.html`):

```html
<!-- In the <head> section -->
<link rel="stylesheet" href="/static/css/reports.css">

<!-- Add a tab button in your navigation -->
<button class="nav-tab" data-tab="reports">📊 Reports</button>

<!-- Add the reports container in your content area -->
<div id="reports-container" class="tab-content" data-tab="reports"></div>

<!-- Before closing </body> -->
<script src="/static/js/reports.js"></script>
```

### 3. Create Report Scripts Directory

```bash
mkdir -p $BASE_DIR/scripts/reports/{database,system,deployment}

# Copy sample scripts
cp scripts/reports/database/*.sh $BASE_DIR/scripts/reports/database/
cp scripts/reports/system/*.sh $BASE_DIR/scripts/reports/system/
```

## Script Format

Report scripts are regular shell/python scripts with special header comments:

```bash
#!/bin/bash
# REPORT_NAME: Human-Readable Name
# REPORT_DESC: Description of what this report shows
# REPORT_CATEGORY: Category Name
# REPORT_TIME: ~30 seconds

# Your script code here...
echo "Report output"
```

### Metadata Fields

| Field | Required | Description |
|-------|----------|-------------|
| `REPORT_NAME` | No | Display name (defaults to filename) |
| `REPORT_DESC` | No | Short description |
| `REPORT_CATEGORY` | No | Group/category (defaults to folder name) |
| `REPORT_TIME` | No | Estimated runtime |

### Directory Structure = Categories

```
scripts/reports/
├── database/           → Category: "Database"
│   ├── db_status.sh
│   └── session_count.sh
├── system/             → Category: "System"
│   ├── health_check.sh
│   └── disk_usage.sh
└── deployment/         → Category: "Deployment"
    └── deploy_status.sh
```

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/reports/scripts` | GET | List all report scripts |
| `/api/reports/scripts/{id}` | GET | Get script details |
| `/api/reports/run/{id}` | POST | Run a report (returns run_id) |
| `/api/reports/result/{id}` | GET | Get run result |
| `/api/reports/ws/{run_id}` | WS | Stream output in real-time |
| `/api/reports/history` | GET | Get recent run history |
| `/api/reports/result/{id}` | DELETE | Cancel running report |

## Security Notes

1. **Authentication Required**: All endpoints require Smart Card auth (inherited from proxy)
2. **Script Location**: Only scripts in `REPORTS_SCRIPTS_DIR` can be executed
3. **Path Validation**: Script IDs are validated to prevent directory traversal
4. **Timeout**: Scripts timeout after 5 minutes (configurable: `MAX_EXECUTION_TIME`)
5. **No Approval**: Reports bypass workflow approval - only use for read-only scripts

## HTML Output Support

Scripts can generate HTML reports by creating a file with the same name but `.html` extension:

```bash
#!/bin/bash
# REPORT_NAME: Database Report with HTML

# Generate text output to stdout
echo "Processing..."

# Generate HTML report
cat > "${0%.sh}_output.html" << 'EOF'
<html>
<body>
  <h1>Database Report</h1>
  <table>
    <tr><th>Database</th><th>Status</th></tr>
    <tr><td>PROD1</td><td style="color:green">Online</td></tr>
  </table>
</body>
</html>
EOF

echo "Report complete - HTML output available"
```

The frontend will detect and display HTML output in a modal.

## Customization

### Change Timeout
```python
# In reports.py
MAX_EXECUTION_TIME = 600  # 10 minutes
```

### Add Parameters
Reports can accept parameters via environment variables:

```python
# Request
POST /api/reports/run/db_status
{
    "parameters": {
        "database": "PROD1",
        "verbose": "true"
    }
}
```

```bash
# In script - parameters are prefixed with REPORT_PARAM_
#!/bin/bash
echo "Database: $REPORT_PARAM_DATABASE"
echo "Verbose: $REPORT_PARAM_VERBOSE"
```

### Styling

Override CSS variables in your main stylesheet:

```css
:root {
    --bg-primary: #0d1421;
    --bg-secondary: #1a2332;
    --bg-tertiary: #0d1421;
    --text-primary: #e2e8f0;
    --text-secondary: #a0aec0;
    --text-muted: #718096;
    --accent-color: #4fd1c5;
    --border-color: #2d3748;
}
```

## Troubleshooting

### Scripts not appearing
- Check `REPORTS_SCRIPTS_DIR` is set correctly
- Verify scripts have `.sh`, `.py`, or `.pl` extension
- Check file permissions

### WebSocket not connecting
- Ensure your proxy forwards WebSocket connections
- Check `/api/reports/ws/*` is routed correctly

### Script fails immediately
- Check script has execute permissions: `chmod +x script.sh`
- Verify shebang line: `#!/bin/bash`
- Check script runs manually: `bash /path/to/script.sh`
