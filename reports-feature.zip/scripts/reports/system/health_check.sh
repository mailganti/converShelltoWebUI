#!/bin/bash
# REPORT_NAME: System Health Check
# REPORT_DESC: Shows CPU, memory, disk usage and service status
# REPORT_CATEGORY: System
# REPORT_TIME: ~5 seconds

echo "=========================================="
echo "  System Health Report"
echo "=========================================="
echo "Host: $(hostname)"
echo "Time: $(date)"
echo ""

echo "--- CPU Usage ---"
top -bn1 | head -5
echo ""

echo "--- Memory Usage ---"
free -h
echo ""

echo "--- Disk Usage ---"
df -h | grep -E '^/dev|Filesystem'
echo ""

echo "--- Key Services ---"
for svc in httpd oracle hypercorn; do
    if pgrep -x "$svc" > /dev/null 2>&1; then
        echo "  ✓ $svc: running"
    else
        echo "  ✗ $svc: not running"
    fi
done
echo ""

echo "--- Recent System Load ---"
uptime
echo ""

echo "✓ Health check complete"
