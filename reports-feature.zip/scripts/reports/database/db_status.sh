#!/bin/bash
# REPORT_NAME: Database Connection Status
# REPORT_DESC: Shows current Oracle database connection status and session counts
# REPORT_CATEGORY: Database
# REPORT_TIME: ~10 seconds

echo "=========================================="
echo "  Database Connection Status Report"
echo "=========================================="
echo "Generated: $(date)"
echo ""

# Check if Oracle environment is set
if [ -z "$ORACLE_HOME" ]; then
    echo "⚠ ORACLE_HOME not set - using defaults"
    export ORACLE_HOME=/u01/app/oracle/product/19c/dbhome_1
    export PATH=$ORACLE_HOME/bin:$PATH
fi

echo "Checking database connections..."
echo ""

# Example - replace with actual DB check
echo "Database: PROD1"
echo "  Status: ONLINE"
echo "  Active Sessions: 42"
echo "  Idle Sessions: 18"
echo ""

echo "Database: PROD2"
echo "  Status: ONLINE"
echo "  Active Sessions: 28"
echo "  Idle Sessions: 12"
echo ""

echo "=========================================="
echo "  Summary"
echo "=========================================="
echo "Total Databases: 2"
echo "Total Active: 70"
echo "Total Idle: 30"
echo ""
echo "✓ All databases operational"
