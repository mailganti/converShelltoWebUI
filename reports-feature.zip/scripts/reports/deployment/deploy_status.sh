#!/bin/bash
# REPORT_NAME: Deployment Status
# REPORT_DESC: Shows status of recent deployments and pending approvals
# REPORT_CATEGORY: Deployment
# REPORT_TIME: ~15 seconds

echo "=========================================="
echo "  Deployment Status Report"
echo "=========================================="
echo "Generated: $(date)"
echo ""

echo "--- Recent Deployments (Last 24h) ---"
echo ""
printf "%-20s %-12s %-15s %s\n" "SCRIPT" "STATUS" "USER" "TIME"
printf "%-20s %-12s %-15s %s\n" "--------------------" "------------" "---------------" "----"
printf "%-20s %-12s %-15s %s\n" "deploy_app.sh" "✓ SUCCESS" "john.snow" "2h ago"
printf "%-20s %-12s %-15s %s\n" "update_config.sh" "✓ SUCCESS" "jane.doe" "5h ago"
printf "%-20s %-12s %-15s %s\n" "restart_services.sh" "✗ FAILED" "john.snow" "8h ago"
echo ""

echo "--- Pending Approvals ---"
echo ""
echo "  • deploy_prod.sh (requested by: mike.smith, 30 min ago)"
echo "  • database_patch.sh (requested by: jane.doe, 2h ago)"
echo ""

echo "--- Agent Status ---"
echo ""
printf "%-15s %-10s %-15s\n" "AGENT" "STATUS" "LAST SEEN"
printf "%-15s %-10s %-15s\n" "---------------" "----------" "---------------"
printf "%-15s %-10s %-15s\n" "agent-prod-01" "● ONLINE" "Just now"
printf "%-15s %-10s %-15s\n" "agent-prod-02" "● ONLINE" "2 min ago"
printf "%-15s %-10s %-15s\n" "agent-dev-01" "○ OFFLINE" "3 hours ago"
echo ""

echo "=========================================="
echo "  Summary"
echo "=========================================="
echo "Deployments (24h): 3 (2 success, 1 failed)"
echo "Pending Approvals: 2"
echo "Agents Online: 2/3"
echo ""
echo "✓ Report complete"
