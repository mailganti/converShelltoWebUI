/* =============================================================================
 * Orchestration Control Panel - Application JavaScript
 * Handles workflows, agents, scripts, and reports management
 * ============================================================================= */

'use strict';

const API_BASE = '/api';
let currentUser = null, workflows = [], agents = [], scripts = [], selectedAgents = [], logs = [], logfiles = {}, selectedWorkflow = null, logsExpanded = true, loading = false;
let currentTab = 'workflows';
let workflowFilter = 'all', agentFilter = 'all', agentEnvFilter = 'all';
let userAllowedEnvironments = [];
let refreshCountdown = 30;
let countdownInterval = null;
let activityFooterExpanded = true;

function switchTab(tabName) {
    currentTab = tabName;
    // Update tab buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
        const isActive = btn.id === `tabBtn${tabName.charAt(0).toUpperCase() + tabName.slice(1)}`;
        btn.classList.toggle('active', isActive);
    });
    // Update tab content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.toggle('active', content.id === `tab-${tabName}`);
    });
    // Initialize Reports tab
    if (tabName === 'reports' && typeof ReportsModule !== 'undefined') {
        ReportsModule.init();
    }
}

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Don't trigger if typing in an input
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') return;
    
    if (e.key === '1') switchTab('workflows');
    else if (e.key === '2' && hasRole('admin')) switchTab('agents');
    else if (e.key === '3' && hasRole('admin')) switchTab('scripts');
    else if (e.key === '4') switchTab('reports');
    else if (e.key === 'r' || e.key === 'R') { loadData(); loadScripts(); }
});

// Activity footer toggle
function toggleActivityFooter() {
    activityFooterExpanded = !activityFooterExpanded;
    document.getElementById('activityFooter').classList.toggle('collapsed', !activityFooterExpanded);
    document.getElementById('footerSpacer').classList.toggle('collapsed', !activityFooterExpanded);
    document.getElementById('footerToggle').textContent = activityFooterExpanded ? '▼ Click to collapse' : '▲ Click to expand';
}

// Filter functions
function filterWorkflows(status) {
    workflowFilter = status;
    document.querySelectorAll('#tab-workflows .filter-btn').forEach(btn => {
        btn.classList.toggle('active', btn.textContent.toLowerCase().includes(status) || (status === 'all' && btn.textContent === 'All'));
    });
    renderWorkflows();
}

function filterAgents(status) {
    agentFilter = status;
    document.querySelectorAll('#tab-agents .filter-bar .filter-btn').forEach(btn => {
        const btnText = btn.textContent.toLowerCase();
        if (btnText === 'all' || btnText === 'online' || btnText === 'offline') {
            btn.classList.toggle('active', btnText === status);
        }
    });
    renderAgents();
}

function filterAgentsByEnv(env) {
    agentEnvFilter = env;
    document.getElementById('envFilterAll').classList.toggle('active', env === 'all');
    document.getElementById('envFilterDev').classList.toggle('active', env === 'DEV');
    document.getElementById('envFilterTest').classList.toggle('active', env === 'TEST');
    document.getElementById('envFilterProd').classList.toggle('active', env === 'PROD');
    renderAgents();
}

// Auto-refresh countdown
function startCountdown() {
    if (countdownInterval) clearInterval(countdownInterval);
    refreshCountdown = 30;
    updateCountdownDisplay();
    countdownInterval = setInterval(() => {
        refreshCountdown--;
        updateCountdownDisplay();
        if (refreshCountdown <= 0) {
            loadData();
            refreshCountdown = 30;
        }
    }, 1000);
}

function updateCountdownDisplay() {
    const el = document.getElementById('refreshCountdown');
    if (el) el.textContent = refreshCountdown;
}

function updateTabBadges() {
    const pendingCount = workflows.filter(w => w.status === 'pending').length;
    const onlineAgents = agents.filter(a => a.status === 'online').length;
    
    document.getElementById('tabBadgeWorkflows').textContent = workflows.length;
    document.getElementById('tabBadgeWorkflows').classList.toggle('pending', pendingCount > 0);
    if (pendingCount > 0) {
        document.getElementById('tabBadgeWorkflows').textContent = `${pendingCount} pending`;
    }
    
    document.getElementById('tabBadgeAgents').textContent = agents.length > 0 ? `${onlineAgents}/${agents.length}` : '0';
    document.getElementById('tabBadgeScripts').textContent = scripts.length;
}

// Update Agents KPIs
function updateAgentsKPIs() {
    const total = agents.length;
    const online = agents.filter(a => a.status === 'online').length;
    const offline = total - online;
    
    document.getElementById('kpiAgentsTotal').textContent = total;
    document.getElementById('kpiAgentsOnline').textContent = online;
    document.getElementById('kpiAgentsOffline').textContent = offline;
}

// Update Scripts KPIs
function updateScriptsKPIs() {
    const total = scripts.length;
    const avgTimeout = total > 0 
        ? Math.round(scripts.reduce((sum, s) => sum + (s.timeout || 300), 0) / total)
        : 0;
    
    document.getElementById('kpiScriptsTotal').textContent = total;
    document.getElementById('kpiScriptsTimeout').textContent = `${avgTimeout}s`;
}

// Update environment access display
function updateEnvAccessDisplay() {
    const container = document.getElementById('userEnvBadges');
    if (!container) return;
    
    if (userAllowedEnvironments.length === 0) {
        container.innerHTML = '<span style="color: var(--rose-200);">No access configured</span>';
        return;
    }
    
    if (userAllowedEnvironments.includes('*')) {
        container.innerHTML = '<span class="env-badge env-dev">DEV</span> <span class="env-badge env-test">TEST</span> <span class="env-badge env-prod">PROD</span> <span style="color: var(--emerald-200); margin-left: 4px;">(Full Access)</span>';
        return;
    }
    
    container.innerHTML = userAllowedEnvironments.map(env => {
        const envLower = env.toLowerCase();
        return `<span class="env-badge env-${envLower}">${env}</span>`;
    }).join(' ');
}

document.addEventListener('DOMContentLoaded', () => { 
    loadUserInfo(); 
    loadScripts(); 
    loadApprovers(); 
    loadData(); 
    startCountdown();
});

async function loadUserInfo() {
    try {
        const res = await fetch('/whoami', { credentials: 'include' });
        if (res.ok) {
            const data = await res.json();
            if (data.logged_in && data.user) {
                currentUser = data.user;
                const displayName = data.user.full_name || data.user.username || 'Unknown User';
                document.getElementById('userName').textContent = displayName;
                const method = data.user.auth_method || 'smartcard';
                const methodLabels = { 'smartcard': '🔐 Smart Card', 'cert': '🔐 Smart Card', 'wna': '🪟 Windows Auth', 'password': '🔑 Password' };
                document.getElementById('authMethod').textContent = methodLabels[method] || method;
                document.getElementById('wfRequestor').value = data.user.username || displayName;
                // Auto-populate requestor email if available
                if (data.user.email) {
                    document.getElementById('wfRequestorEmail').value = data.user.email;
                }
                // Apply role-based visibility
                applyRoleVisibility();
                addLog(`Authenticated as ${displayName} (${currentUser.role || 'user'})`, 'success');
            } else {
                window.location.href = '/login.html';
            }
        } else {
            window.location.href = '/login.html';
        }
    } catch (err) {
        document.getElementById('userName').textContent = 'Auth Error';
        document.getElementById('authMethod').textContent = 'Connection Failed';
        addLog(`Authentication error: ${err.message}`, 'error');
    }
}

// Role-based visibility
// Roles: admin (all access), approver (workflows + activity log), operator (workflows + activity log), user (workflows only)
function hasRole(...roles) {
    if (!currentUser) return false;
    const userRole = (currentUser.role || 'user').toLowerCase();
    // Admin always has access to everything
    if (userRole === 'admin') return true;
    return roles.map(r => r.toLowerCase()).includes(userRole);
}

function applyRoleVisibility() {
    const userRole = (currentUser?.role || 'user').toLowerCase();
    
    // Set role badge in header
    const roleBadge = document.getElementById('userRole');
    if (roleBadge) {
        roleBadge.textContent = userRole;
        roleBadge.className = `user-role-badge ${userRole}`;
    }
    
    // Agents tab - Admin only
    const agentsTab = document.getElementById('tabBtnAgents');
    if (agentsTab) {
        agentsTab.style.display = hasRole('admin') ? '' : 'none';
    }
    
    // Scripts tab - Admin only
    const scriptsTab = document.getElementById('tabBtnScripts');
    if (scriptsTab) {
        scriptsTab.style.display = hasRole('admin') ? '' : 'none';
    }
    
    // Register Report section - Admin only
    const registerReportSection = document.getElementById('registerReportSection');
    if (registerReportSection) {
        registerReportSection.style.display = hasRole('admin') ? '' : 'none';
    }
    
    // Activity Log footer - Admin, Approver, Operator only
    const activityFooter = document.getElementById('activityFooter');
    const footerSpacer = document.getElementById('footerSpacer');
    if (activityFooter) {
        const canSeeLog = hasRole('admin', 'approver', 'operator');
        activityFooter.style.display = canSeeLog ? '' : 'none';
        if (footerSpacer) footerSpacer.style.display = canSeeLog ? '' : 'none';
    }
    
    // Update keyboard shortcut hints based on visible tabs
    updateKeyboardHints();
    
    // If current tab is now hidden, switch to workflows
    if (currentTab === 'agents' && !hasRole('admin')) {
        switchTab('workflows');
    }
    if (currentTab === 'scripts' && !hasRole('admin')) {
        switchTab('workflows');
    }
    
    addLog(`Role permissions applied: ${userRole}`, 'info');
}

function updateKeyboardHints() {
    // Update keyboard hints based on visible tabs
    const agentsKbd = document.querySelector('#tabBtnAgents .kbd');
    const scriptsKbd = document.querySelector('#tabBtnScripts .kbd');
    
    if (agentsKbd && !hasRole('admin')) agentsKbd.style.display = 'none';
    if (scriptsKbd && !hasRole('admin')) scriptsKbd.style.display = 'none';
}

async function loadScripts() {
    try {
        const res = await fetch(`${API_BASE}/scripts`, { credentials: 'include' });
        if (res.ok) {
            const data = await res.json();
            scripts = data.scripts || [];
            renderScriptDropdown();
            renderScriptsTable();
            updateTabBadges();
            updateScriptsKPIs();
            addLog(`Loaded ${scripts.length} scripts`, 'success');
        }
    } catch (err) {
        addLog(`Failed to load scripts: ${err.message}`, 'error');
        renderScriptDropdown();
        renderScriptsTable();
    }
}

function renderScriptDropdown() {
    const select = document.getElementById('wfScriptId');
    if (scripts.length === 0) {
        select.innerHTML = '<option value="">No scripts registered</option>';
        return;
    }
    select.innerHTML = '<option value="">-- Select a script --</option>' + 
        scripts.map(s => `<option value="${escapeHtml(s.script_id)}" title="${escapeHtml(s.description || '')}">${escapeHtml(s.script_id)}${s.description ? ' - ' + escapeHtml(s.description.substring(0, 30)) : ''}</option>`).join('');
}

function renderScriptsTable() {
    const tbody = document.getElementById('scriptsTable');
    if (scripts.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="empty-row">No scripts registered</td></tr>';
        return;
    }
    tbody.innerHTML = scripts.map(s => `
        <tr>
            <td><span style="font-family: monospace; color: var(--sky-400);">${escapeHtml(s.script_id)}</span></td>
            <td style="font-size: 11px; color: var(--text-secondary); max-width: 300px; overflow: hidden; text-overflow: ellipsis;">${escapeHtml(s.script_path || s.path || '')}</td>
            <td style="font-size: 11px;">${escapeHtml(s.description || '-')}</td>
            <td style="font-size: 11px;">${s.timeout || 300}s</td>
        </tr>
    `).join('');
}

let approvers = [];

async function loadApprovers() {
    try {
        const res = await fetch(`${API_BASE}/users/approvers`, { credentials: 'include' });
        if (res.ok) {
            const data = await res.json();
            approvers = data.approvers || [];
            renderApproverDropdown();
            addLog(`Loaded ${approvers.length} approvers`, 'success');
        } else {
            // Fallback: allow manual email entry
            renderApproverDropdown();
        }
    } catch (err) {
        addLog(`Could not load approvers: ${err.message}`, 'info');
        renderApproverDropdown();
    }
}

function renderApproverDropdown() {
    const select = document.getElementById('wfApproverEmail');
    if (approvers.length === 0) {
        // No approvers in DB - convert to text input for manual entry
        const parent = select.parentElement;
        const input = document.createElement('input');
        input.type = 'email';
        input.className = 'form-input';
        input.id = 'wfApproverEmail';
        input.placeholder = 'approver@company.com';
        input.required = true;
        select.replaceWith(input);
        return;
    }
    select.innerHTML = '<option value="">-- Select approver --</option>' + 
        approvers.map(a => {
            const display = a.full_name ? `${a.full_name} (${a.username})` : a.username;
            const email = a.email || '';
            return `<option value="${escapeHtml(email)}" title="${escapeHtml(a.role || 'approver')}">${escapeHtml(display)}${email ? ' - ' + escapeHtml(email) : ''}</option>`;
        }).join('');
}

async function registerScript() {
    const scriptId = document.getElementById('scriptId').value.trim();
    const scriptPath = document.getElementById('scriptPath').value.trim();
    const description = document.getElementById('scriptDescription').value.trim();
    const timeout = parseInt(document.getElementById('scriptTimeout').value) || 300;

    if (!scriptId) { addLog('Please enter a Script ID', 'error'); return; }
    if (!scriptPath) { addLog('Please enter a Script Path', 'error'); return; }
    if (!/^[a-zA-Z0-9_-]+$/.test(scriptId)) { addLog('Script ID must contain only letters, numbers, hyphens and underscores', 'error'); return; }

    try {
        await apiCall('/scripts/register', {
            method: 'POST',
            body: JSON.stringify({
                script_id: scriptId,
                script_path: scriptPath,
                description: description,
                timeout: timeout
            })
        });
        addLog(`Script '${scriptId}' registered successfully`, 'success');
        document.getElementById('scriptId').value = '';
        document.getElementById('scriptPath').value = '';
        document.getElementById('scriptDescription').value = '';
        document.getElementById('scriptTimeout').value = '300';
        loadScripts();
    } catch (err) {
        addLog(`Failed to register script: ${err.message}`, 'error');
    }
}

async function apiCall(endpoint, options = {}) {
    const url = endpoint.startsWith('/api') ? endpoint : `${API_BASE}${endpoint}`;
    try {
        const res = await fetch(url, { ...options, headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }, credentials: 'include' });
        if (!res.ok) { const err = await res.json().catch(() => ({ detail: 'Unknown error' })); throw new Error(err.detail || `HTTP ${res.status}`); }
        return await res.json();
    } catch (err) { addLog(`API Error: ${err.message}`, 'error'); throw err; }
}

async function loadData() {
    if (loading) return;
    loading = true;
    document.getElementById('refreshBtn').classList.add('spinning');
    addLog('Loading data...');
    try {
        const [wfResp, agResp] = await Promise.all([apiCall('/workflows').catch(() => ({ workflows: [] })), apiCall('/agents/').catch(() => ({ agents: [] }))]);
        workflows = Array.isArray(wfResp) ? wfResp : wfResp.workflows || [];
        agents = Array.isArray(agResp) ? agResp : agResp.agents || [];
        
        // Store user's allowed environments from the agents response
        if (agResp.allowed_environments) {
            userAllowedEnvironments = agResp.allowed_environments;
            updateEnvAccessDisplay();
        }
        
        renderWorkflows(); renderAgents(); updateKPIs(); updateAgentsKPIs(); updateTabBadges();
        // Refresh Reports tab agent dropdown
        if (typeof ReportsModule !== 'undefined') ReportsModule.refreshAgents();
        refreshCountdown = 30; // Reset countdown
        addLog('Data loaded successfully', 'success');
    } catch (err) { addLog(`Failed to load data: ${err.message}`, 'error'); }
    finally { loading = false; document.getElementById('refreshBtn').classList.remove('spinning'); }
}

function renderWorkflows() {
    const tbody = document.getElementById('workflowsTable');
    const filtered = workflowFilter === 'all' ? workflows : workflows.filter(w => w.status === workflowFilter);
    if (filtered.length === 0) { 
        tbody.innerHTML = `<tr><td colspan="5" class="empty-row">${workflowFilter === 'all' ? 'No workflows found' : `No ${workflowFilter} workflows`}</td></tr>`; 
        return; 
    }
    tbody.innerHTML = filtered.map(wf => {
        const isSelected = wf.workflow_id === selectedWorkflow, hasLogs = logfiles[wf.workflow_id];
        return `<tr class="${isSelected ? 'selected' : ''}" onclick="selectWorkflow('${wf.workflow_id}')">
            <td>${escapeHtml(wf.workflow_id)}</td>
            <td><span class="script-badge">${escapeHtml(wf.script_id)}</span></td>
            <td><span class="badge badge-${wf.status}">${wf.status}</span></td>
            <td style="font-size: 11px; color: var(--text-secondary);">${formatDate(wf.created_at)}</td>
            <td class="text-right">
                ${hasLogs ? `<span class="badge badge-logs" style="cursor:pointer;" onclick="event.stopPropagation(); openWorkflowLog('${wf.workflow_id}')">Logs</span>` : ''}
                ${wf.status === 'pending' ? `
                    <button class="action-btn action-btn-secondary" onclick="event.stopPropagation(); approveWorkflow('${wf.workflow_id}')">Approve</button>
                    <button class="action-btn action-btn-danger" onclick="event.stopPropagation(); denyWorkflow('${wf.workflow_id}')">Deny</button>
                ` : ''}
                ${wf.status === 'approved' ? `<button class="action-btn action-btn-primary" onclick="event.stopPropagation(); executeWorkflow('${wf.workflow_id}')">Execute</button>` : ''}
                ${wf.status === 'executing' ? `<span class="badge badge-executing">⏳ Running...</span>` : ''}
                ${wf.status === 'executed' ? `<span class="badge badge-executed">✓ Completed</span>` : ''}
                ${wf.status === 'failed' ? `<span class="badge badge-failed">✗ Failed</span>` : ''}
                ${wf.status === 'denied' ? `<span class="badge badge-denied">Denied</span>` : ''}
            </td></tr>`;
    }).join('');
}

function renderAgents() {
    const tbody = document.getElementById('agentsTable'), selector = document.getElementById('agentSelector');
    
    // Apply both status and environment filters
    let filtered = agents;
    if (agentFilter !== 'all') {
        filtered = filtered.filter(a => a.status === agentFilter);
    }
    if (agentEnvFilter !== 'all') {
        filtered = filtered.filter(a => (a.environment || 'DEV').toUpperCase() === agentEnvFilter);
    }
    
    if (agents.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="empty-row">No agents registered</td></tr>';
        selector.innerHTML = '<div style="padding: 0.25rem; text-align: center; color: var(--text-secondary); font-size: 11px;">No agents registered. Register an agent first →</div>';
        return;
    }
    
    if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="empty-row">No matching agents</td></tr>`;
    } else {
        tbody.innerHTML = filtered.map(a => {
            const env = (a.environment || 'DEV').toUpperCase();
            const envClass = env.toLowerCase();
            return `<tr>
                <td>${escapeHtml(a.agent_name)}</td>
                <td>${escapeHtml(a.host)}</td>
                <td>${a.port}</td>
                <td><span class="env-badge env-${envClass}">${env}</span></td>
                <td><span class="badge badge-${a.status === 'online' ? 'online' : 'offline'}">${a.status}</span></td>
                <td style="font-size: 11px; color: var(--text-secondary);">${formatDate(a.last_seen)}</td>
            </tr>`;
        }).join('');
    }
    
    // Selector always shows all agents for workflow creation (with environment info)
    selector.innerHTML = agents.map(a => {
        const env = (a.environment || 'DEV').toUpperCase();
        const envClass = env.toLowerCase();
        return `<label class="agent-option">
            <input type="checkbox" value="${escapeHtml(a.agent_name)}" ${selectedAgents.includes(a.agent_name) ? 'checked' : ''} onchange="toggleAgentSelection('${escapeHtml(a.agent_name)}', this.checked)">
            <span class="agent-option-name">${escapeHtml(a.agent_name)}</span>
            <span class="agent-option-env env-badge env-${envClass}">${env}</span>
            <span class="agent-option-status ${a.status}">${a.status}</span>
        </label>`;
    }).join('');
}

function updateKPIs() {
    document.getElementById('kpiTotal').textContent = workflows.length;
    document.getElementById('kpiPending').textContent = workflows.filter(w => w.status === 'pending').length;
    document.getElementById('kpiApproved').textContent = workflows.filter(w => w.status === 'approved').length;
    document.getElementById('kpiExecuted').textContent = workflows.filter(w => w.status === 'executed').length;
}

function selectWorkflow(id) { selectedWorkflow = id; renderWorkflows(); updateLogsPanel(); }

async function createWorkflow() {
    const scriptId = document.getElementById('wfScriptId').value;
    const requestor = document.getElementById('wfRequestor').value.trim();
    const requestorEmail = document.getElementById('wfRequestorEmail').value.trim();
    const approverEmail = document.getElementById('wfApproverEmail').value.trim();
    const reason = document.getElementById('wfReason').value.trim();
    
    if (!scriptId) { addLog('Please select a script', 'error'); return; }
    if (!requestor || !reason) { addLog('Please fill in all workflow fields', 'error'); return; }
    if (!approverEmail) { addLog('Please enter approver email for notifications', 'error'); return; }
    if (selectedAgents.length === 0) { addLog('Please select at least one target agent', 'error'); return; }
    
    try {
        await apiCall('/workflows', { 
            method: 'POST', 
            body: JSON.stringify({ 
                script_id: scriptId, 
                targets: selectedAgents, 
                requestor, 
                requestor_email: requestorEmail,
                notify_email: approverEmail,
                reason, 
                required_approval_levels: 1, 
                ttl_minutes: 60 
            }) 
        });
        addLog('Workflow created - approval notification sent to ' + approverEmail, 'success');
        document.getElementById('wfScriptId').selectedIndex = 0; 
        document.getElementById('wfReason').value = '';
        document.getElementById('wfApproverEmail').value = '';
        selectedAgents = []; 
        document.getElementById('selectedCount').textContent = '0'; 
        loadData();
    } catch (err) { addLog(`Failed to create workflow: ${err.message}`, 'error'); }
}

async function approveWorkflow(id) {
    try { await apiCall(`/workflows/${id}/approve`, { method: 'POST', body: JSON.stringify({ approver: currentUser?.username || 'admin', note: 'Approved from dashboard' }) }); addLog(`Workflow ${id} approved`, 'success'); loadData(); }
    catch (err) { addLog(`Failed to approve: ${err.message}`, 'error'); }
}

let pendingDenyWorkflowId = null;

function denyWorkflow(id) {
    pendingDenyWorkflowId = id;
    document.getElementById('denyWorkflowId').textContent = id;
    document.getElementById('denyReason').value = '';
    document.getElementById('denyModal').classList.add('active');
    document.getElementById('denyReason').focus();
}

function closeDenyModal() {
    document.getElementById('denyModal').classList.remove('active');
    pendingDenyWorkflowId = null;
}

async function confirmDeny() {
    if (!pendingDenyWorkflowId) return;
    const reason = document.getElementById('denyReason').value.trim() || 'Denied from dashboard';
    try { 
        await apiCall(`/workflows/${pendingDenyWorkflowId}/deny`, { 
            method: 'POST', 
            body: JSON.stringify({ 
                denier: currentUser?.username || 'admin', 
                reason: reason 
            }) 
        }); 
        addLog(`Workflow ${pendingDenyWorkflowId} denied: ${reason}`, 'warning'); 
        closeDenyModal();
        loadData(); 
    }
    catch (err) { 
        addLog(`Failed to deny: ${err.message}`, 'error'); 
        closeDenyModal();
    }
}

async function executeWorkflow(id) {
    try {
        addLog(`Executing workflow ${id}...`, 'info');
        const result = await apiCall(`/workflows/${id}/execute`, { method: 'POST' });
        
        // Check execution result
        const successCount = result?.script_result?.success_count ?? result?.success_count ?? 0;
        const failureCount = result?.script_result?.failure_count ?? result?.failure_count ?? 0;
        
        if (failureCount === 0) {
            addLog(`✅ Workflow ${id} executed successfully on ${successCount} agent(s)`, 'success');
        } else {
            addLog(`⚠️ Workflow ${id} completed with ${failureCount} failure(s)`, 'error');
        }
        
        // Extract logfiles (HTML and text) if present
        const stdout = result?.script_result?.results?.[0]?.result?.stdout ?? result?.script_result?.results?.[0]?.stdout ?? '';
        const files = extractAllLogfiles(stdout);
        if (files.html || files.text) { 
            logfiles[id] = files;
            if (files.html) addLog(`HTML output: ${files.html}`, 'success');
            if (files.text) addLog(`Text log: ${files.text}`, 'success'); 
            selectedWorkflow = id; 
            logsExpanded = true; 
            updateLogsPanel(); 
        }
        
        // Refresh data to show updated status
        await loadData();
        
    } catch (err) { 
        addLog(`❌ Execution failed: ${err.message}`, 'error'); 
        await loadData(); // Refresh anyway to show failed status
    }
}

function extractLogfile(stdout) { 
    if (!stdout) return null; 
    const clean = stdout.replace(/\u001b\[[0-9;]*m/g, '').replace(/\/\/+/g, '/'); 
    // First try to find HTML file
    const htmlMatch = clean.match(/(\/[A-Za-z0-9_\-\/\.]+\.html)/);
    if (htmlMatch) return htmlMatch[1];
    // Fall back to log file
    const logMatch = clean.match(/(\/[A-Za-z0-9_\-\/\.]+\.log)/); 
    return logMatch ? logMatch[1] : null; 
}

function extractAllLogfiles(stdout) {
    if (!stdout) return { html: null, text: null };
    const clean = stdout.replace(/\u001b\[[0-9;]*m/g, '').replace(/\/\/+/g, '/');
    const htmlMatch = clean.match(/(\/[A-Za-z0-9_\-\/\.]+\.html)/);
    const logMatch = clean.match(/(\/[A-Za-z0-9_\-\/\.]+\.log)/);
    return { html: htmlMatch ? htmlMatch[1] : null, text: logMatch ? logMatch[1] : null };
}

function toggleAgentSelection(name, checked) { if (checked) { if (!selectedAgents.includes(name)) selectedAgents.push(name); } else { selectedAgents = selectedAgents.filter(a => a !== name); } document.getElementById('selectedCount').textContent = selectedAgents.length; }

async function registerAgent() {
    const name = document.getElementById('agentName').value.trim();
    const host = document.getElementById('agentHost').value.trim();
    const portStr = document.getElementById('agentPort').value.trim();
    const environment = document.getElementById('agentEnvironment').value;
    
    if (!name || !host || !portStr) { addLog('Please fill in all agent fields', 'error'); return; }
    const port = parseInt(portStr, 10); 
    if (isNaN(port) || port < 1 || port > 65535) { addLog('Port must be between 1-65535', 'error'); return; }
    
    try { 
        await apiCall('/agents/', { 
            method: 'POST', 
            body: JSON.stringify({ 
                agent_name: name, 
                host, 
                port,
                environment: environment
            }) 
        }); 
        addLog(`Agent ${name} registered in ${environment} environment`, 'success'); 
        document.getElementById('agentName').value = ''; 
        document.getElementById('agentHost').value = ''; 
        document.getElementById('agentPort').value = '8001'; 
        document.getElementById('agentEnvironment').value = 'DEV';
        loadData(); 
    }
    catch (err) { addLog(`Failed to register agent: ${err.message}`, 'error'); }
}

function updateLogsPanel() {
    const panel = document.getElementById('logsPanel');
    const files = selectedWorkflow ? logfiles[selectedWorkflow] : null;
    
    // Handle both old format (string) and new format ({html, text})
    const htmlFile = typeof files === 'object' ? files?.html : null;
    const textFile = typeof files === 'object' ? files?.text : (typeof files === 'string' ? files : null);
    
    if (!selectedWorkflow || (!htmlFile && !textFile)) { 
        panel.classList.add('hidden'); 
        return; 
    }
    
    panel.classList.remove('hidden');
    document.getElementById('logsWorkflowId').textContent = selectedWorkflow;
    // Show HTML path if available (primary), otherwise text
    document.getElementById('logsPath').textContent = htmlFile || textFile;
    document.getElementById('logsIcon').textContent = logsExpanded ? '▼' : '►';
    document.getElementById('logsContent').classList.toggle('hidden', !logsExpanded);
    
    // Show/hide buttons based on available files
    // HTML is primary (btn-primary), Text is secondary
    document.getElementById('btnViewHtml').style.display = htmlFile ? 'inline-block' : 'none';
    document.getElementById('btnViewText').style.display = textFile ? 'inline-block' : 'none';
}

function toggleLogs() { logsExpanded = !logsExpanded; updateLogsPanel(); }

function viewHtmlLog() { 
    const files = logfiles[selectedWorkflow]; 
    const path = typeof files === 'object' ? files?.html : null;
    if (path) window.open(`${API_BASE}/logs/file?path=${encodeURIComponent(path)}`, '_blank'); 
}

function viewTextLog() { 
    const files = logfiles[selectedWorkflow]; 
    const path = typeof files === 'object' ? files?.text : (typeof files === 'string' ? files : null);
    if (path) window.open(`${API_BASE}/logs/file?path=${encodeURIComponent(path)}`, '_blank'); 
}

function viewLiveLogs() { 
    const files = logfiles[selectedWorkflow]; 
    // Prefer HTML file for live view
    const path = typeof files === 'object' ? (files?.html || files?.text) : files;
    if (path) window.open(`${API_BASE}/logs/tail?path=${encodeURIComponent(path)}`, '_blank'); 
}

// Default view - opens HTML if available, otherwise text
function viewDefaultLog() {
    const files = logfiles[selectedWorkflow];
    const path = typeof files === 'object' ? (files?.html || files?.text) : files;
    if (path) window.open(`${API_BASE}/logs/file?path=${encodeURIComponent(path)}`, '_blank');
}

// Open log for specific workflow - opens HTML if available
function openWorkflowLog(workflowId) {
    const files = logfiles[workflowId];
    const path = typeof files === 'object' ? (files?.html || files?.text) : files;
    if (path) window.open(`${API_BASE}/logs/file?path=${encodeURIComponent(path)}`, '_blank');
}

function addLog(message, type = 'info') { const ts = new Date().toLocaleTimeString(); logs.push({ message, type, timestamp: ts }); if (logs.length > 50) logs.shift(); const ta = document.getElementById('activityLog'); ta.value = logs.map(l => `${l.timestamp} [${l.type.toUpperCase()}] ${l.message}`).join('\n'); ta.scrollTop = ta.scrollHeight; }
function clearLogs() { logs = []; document.getElementById('activityLog').value = ''; }

function escapeHtml(t) { if (!t) return ''; const d = document.createElement('div'); d.textContent = t; return d.innerHTML; }
function formatDate(ds) { if (!ds) return 'Never'; const d = new Date(ds), n = new Date(), m = Math.floor((n - d) / 60000); if (m < 1) return 'Just now'; if (m < 60) return `${m}m ago`; const h = Math.floor(m / 60); if (h < 24) return `${h}h ago`; return d.toLocaleDateString(); }

// Modal keyboard support
document.addEventListener('keydown', (e) => {
    const modal = document.getElementById('denyModal');
    if (!modal.classList.contains('active')) return;
    if (e.key === 'Escape') closeDenyModal();
    if (e.key === 'Enter' && e.ctrlKey) confirmDeny();
});

// Close modal on overlay click
document.getElementById('denyModal').addEventListener('click', (e) => {
    if (e.target.id === 'denyModal') closeDenyModal();
});


// ====================================================================
// Reports Module - With Parameters Support
// ====================================================================
const ReportsModule = (function() {
    let reportScripts = [];
    let currentRunId = null;
    let outputSocket = null;
    let initialized = false;
    let selectedReportParams = [];

    function init() {
        console.log('ReportsModule.init called');
        loadScripts();
        renderAgentDropdown();
        initialized = true;
    }

    async function loadScripts() {
        console.log('ReportsModule.loadScripts called');
        try {
            const response = await fetch('/api/reports/scripts', { credentials: 'include' });
            if (!response.ok) throw new Error('API returned ' + response.status);
            const data = await response.json();
            reportScripts = Array.isArray(data) ? data : (data.scripts || []);
            console.log('Loaded reports:', reportScripts.length);
            renderReportsTable();
            renderReportDropdown();
            updateKPIs();
            const badge = document.getElementById('tabBadgeReports');
            if (badge) badge.textContent = reportScripts.length;
            addLog('Loaded ' + reportScripts.length + ' report scripts', 'success');
        } catch (error) {
            console.error('Error loading report scripts:', error);
            addLog('Reports API not available', 'info');
            reportScripts = [];
            renderReportsTable();
            renderReportDropdown();
            updateKPIs();
        }
    }

    function updateKPIs() {
        const totalEl = document.getElementById('kpiReportsTotal');
        const runsEl = document.getElementById('kpiReportsRuns');
        if (totalEl) totalEl.textContent = reportScripts.length;
        if (runsEl) runsEl.textContent = '0';
    }

    function renderReportsTable() {
        const tbody = document.getElementById('reportsTable');
        if (!tbody) return;
        if (reportScripts.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="empty-row">No reports registered. Use the form below to register reports.</td></tr>';
            return;
        }
        tbody.innerHTML = reportScripts.map(r => {
            const id = r.script_id || r.id;
            const params = r.parameters || [];
            const paramCount = params.length;
            const paramNames = params.map(p => p.name).join(', ');
            return '<tr>' +
                '<td><span style="font-family: monospace; color: var(--sky-400);">' + escapeHtml(id) + '</span></td>' +
                '<td>' + escapeHtml(r.name || id) + '</td>' +
                '<td><span class="badge" style="background: var(--slate-bg-80); border-color: var(--slate-500-50);">' + escapeHtml(r.category || 'General') + '</span></td>' +
                '<td style="font-size: 11px;">' + (paramCount > 0 ? '<span title="' + escapeHtml(paramNames) + '" style="color: var(--emerald-200);">' + paramCount + ' param' + (paramCount > 1 ? 's' : '') + '</span>' : '<span style="color: var(--text-muted);">none</span>') + '</td>' +
                '<td style="font-size: 11px;">' + (r.timeout || 300) + 's</td>' +
                '<td class="text-right"><button class="action-btn action-btn-primary" onclick="ReportsModule.quickRun(\'' + escapeHtml(id) + '\')">▶ Run</button></td>' +
                '</tr>';
        }).join('');
    }

    function renderReportDropdown() {
        const select = document.getElementById('reportSelect');
        if (!select) return;
        if (reportScripts.length === 0) {
            select.innerHTML = '<option value="">-- No reports registered --</option>';
            return;
        }
        select.innerHTML = '<option value="">-- Select a report --</option>' + 
            reportScripts.map(r => {
                const id = r.script_id || r.id;
                const paramCount = (r.parameters || []).length;
                const paramHint = paramCount > 0 ? ' [' + paramCount + ' params]' : '';
                return '<option value="' + escapeHtml(id) + '">' + escapeHtml(r.name || id) + ' (' + escapeHtml(r.category || 'General') + ')' + paramHint + '</option>';
            }).join('');
    }

    function renderAgentDropdown() {
        const select = document.getElementById('reportAgentSelect');
        if (!select) {
            console.warn('[Reports] Agent select element not found');
            return;
        }
        
        // First try the global agents array (already loaded by main data call)
        console.log('[Reports] renderAgentDropdown - cached agents:', agents ? agents.length : 'undefined');
        
        if (agents && agents.length > 0) {
            populateAgentSelect(select, agents);
            return;
        }
        
        // Fallback: fetch from /api/agents/all (bypasses environment filtering)
        console.log('[Reports] Cached agents empty, trying /api/agents/all...');
        select.innerHTML = '<option value="">-- Loading agents... --</option>';
        
        fetch('/api/agents/all', { credentials: 'include' })
            .then(res => {
                if (!res.ok) throw new Error('Status ' + res.status);
                return res.json();
            })
            .then(data => {
                const agentList = data.agents || [];
                console.log('[Reports] /api/agents/all returned:', agentList.length, 'agents');
                if (agentList.length === 0) {
                    // Last fallback: try regular /api/agents/
                    return fetch('/api/agents/', { credentials: 'include' })
                        .then(res => res.json())
                        .then(data2 => {
                            const list2 = data2.agents || [];
                            console.log('[Reports] /api/agents/ returned:', list2.length, 'agents');
                            populateAgentSelect(select, list2);
                        });
                }
                populateAgentSelect(select, agentList);
            })
            .catch(err => {
                console.error('[Reports] Failed to fetch agents:', err);
                // Try regular endpoint as final fallback
                fetch('/api/agents/', { credentials: 'include' })
                    .then(res => res.json())
                    .then(data => {
                        populateAgentSelect(select, data.agents || []);
                    })
                    .catch(err2 => {
                        console.error('[Reports] All agent fetches failed:', err2);
                        select.innerHTML = '<option value="">-- Failed to load agents --</option>';
                    });
            });
    }
    
    function populateAgentSelect(select, agentList) {
        if (!agentList || agentList.length === 0) {
            select.innerHTML = '<option value="">-- No agents available --</option>';
            return;
        }
        select.innerHTML = '<option value="">-- Select agent --</option>' + 
            agentList.map(a => {
                const disabled = a.status !== 'online' ? 'disabled' : '';
                const status = a.status === 'online' ? '🟢' : '🔴';
                const env = (a.environment || 'DEV').toUpperCase();
                return '<option value="' + escapeHtml(a.agent_name) + '" ' + disabled + '>' + status + ' ' + escapeHtml(a.agent_name) + ' [' + env + '] (' + escapeHtml(a.host) + ')</option>';
            }).join('');
        console.log('[Reports] Agent dropdown populated with', agentList.length, 'agents');
    }

    function onReportSelect() {
        const scriptId = document.getElementById('reportSelect').value;
        const paramsSection = document.getElementById('reportParamsSection');
        const paramsGrid = document.getElementById('reportParamsGrid');
        
        renderAgentDropdown();
        
        if (!scriptId) {
            paramsSection.style.display = 'none';
            selectedReportParams = [];
            return;
        }
        
        const report = reportScripts.find(r => (r.script_id || r.id) === scriptId);
        if (!report) {
            paramsSection.style.display = 'none';
            selectedReportParams = [];
            return;
        }
        
        selectedReportParams = report.parameters || [];
        
        if (selectedReportParams.length === 0) {
            paramsSection.style.display = 'none';
            return;
        }
        
        paramsGrid.innerHTML = selectedReportParams.map(p => {
            const required = p.required ? '<span style="color: var(--rose-200);">*</span>' : '';
            const inputId = 'param_' + p.name;
            let inputHtml = '';
            
            switch (p.type) {
                case 'select':
                    const options = (p.options || []).map(opt => 
                        '<option value="' + escapeHtml(opt) + '"' + (opt === p.default ? ' selected' : '') + '>' + escapeHtml(opt) + '</option>'
                    ).join('');
                    inputHtml = '<select class="form-input" id="' + inputId + '"' + (p.required ? ' required' : '') + '><option value="">-- Select --</option>' + options + '</select>';
                    break;
                case 'checkbox':
                    inputHtml = '<label style="display: flex; align-items: center; gap: 8px; cursor: pointer;"><input type="checkbox" id="' + inputId + '"' + (p.default ? ' checked' : '') + ' style="width: 16px; height: 16px; accent-color: var(--sky-400);"><span style="font-size: 12px; color: var(--text-secondary);">' + escapeHtml(p.placeholder || 'Enable') + '</span></label>';
                    break;
                case 'number':
                    inputHtml = '<input type="number" class="form-input" id="' + inputId + '" value="' + (p.default || '') + '" placeholder="' + escapeHtml(p.placeholder || '') + '"' + (p.min !== undefined ? ' min="' + p.min + '"' : '') + (p.max !== undefined ? ' max="' + p.max + '"' : '') + (p.required ? ' required' : '') + '>';
                    break;
                case 'date':
                    inputHtml = '<input type="date" class="form-input" id="' + inputId + '" value="' + (p.default || '') + '"' + (p.required ? ' required' : '') + '>';
                    break;
                case 'textarea':
                    inputHtml = '<textarea class="form-input" id="' + inputId + '" rows="2" placeholder="' + escapeHtml(p.placeholder || '') + '"' + (p.required ? ' required' : '') + '>' + escapeHtml(p.default || '') + '</textarea>';
                    break;
                default:
                    inputHtml = '<input type="text" class="form-input" id="' + inputId + '" value="' + escapeHtml(p.default || '') + '" placeholder="' + escapeHtml(p.placeholder || '') + '"' + (p.required ? ' required' : '') + '>';
            }
            
            return '<div class="form-group' + (p.type === 'textarea' ? ' full' : '') + '"><div class="form-label">' + escapeHtml(p.label || p.name) + ' ' + required + '</div>' + inputHtml + '</div>';
        }).join('');
        
        paramsSection.style.display = 'block';
    }

    function collectParameters() {
        const params = {};
        for (const p of selectedReportParams) {
            const el = document.getElementById('param_' + p.name);
            if (!el) continue;
            
            let value;
            if (p.type === 'checkbox') {
                value = el.checked;
            } else if (p.type === 'number') {
                value = el.value ? parseFloat(el.value) : null;
            } else {
                value = el.value;
            }
            
            if (p.required && (value === '' || value === null || value === undefined)) {
                addLog('Parameter "' + (p.label || p.name) + '" is required', 'error');
                el.focus();
                return null;
            }
            params[p.name] = value;
        }
        return params;
    }

    function quickRun(scriptId) {
        document.getElementById('reportSelect').value = scriptId;
        onReportSelect();
        document.getElementById('reportAgentSelect').focus();
    }

    async function runSelectedReport() {
        const scriptId = document.getElementById('reportSelect').value;
        const targetAgent = document.getElementById('reportAgentSelect').value;

        if (!scriptId) { addLog('Please select a report', 'error'); return; }
        if (!targetAgent) { addLog('Please select a target agent', 'error'); return; }
        if (currentRunId) { addLog('A report is already running', 'warning'); return; }

        const parameters = collectParameters();
        if (parameters === null) return;

        document.getElementById('reportOutputPanel').style.display = 'block';
        clearOutput();
        appendOutput('[' + new Date().toLocaleTimeString() + '] Starting report: ' + scriptId + '\n', 'info');
        appendOutput('[' + new Date().toLocaleTimeString() + '] Target: ' + targetAgent + '\n', 'info');
        if (Object.keys(parameters).length > 0) {
            appendOutput('[' + new Date().toLocaleTimeString() + '] Parameters: ' + JSON.stringify(parameters) + '\n', 'info');
        }
        appendOutput('─'.repeat(50) + '\n', 'dim');

        try {
            const response = await fetch('/api/reports/run/' + scriptId, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ target: targetAgent, parameters: parameters })
            });

            if (!response.ok) {
                const err = await response.json().catch(() => ({}));
                throw new Error(err.detail || 'Failed to start report');
            }

            const result = await response.json();
            currentRunId = result.run_id;
            appendOutput('[' + new Date().toLocaleTimeString() + '] Run ID: ' + currentRunId + '\n', 'info');
            addLog('Report ' + scriptId + ' started on ' + targetAgent, 'success');
            connectToOutputStream(currentRunId);
        } catch (error) {
            appendOutput('\n[ERROR] ' + error.message + '\n', 'error');
            addLog('Report failed: ' + error.message, 'error');
            currentRunId = null;  // Clear run state on error
        }
    }

    function connectToOutputStream(runId) {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = protocol + '//' + window.location.host + '/api/reports/ws/' + runId;
        try {
            outputSocket = new WebSocket(wsUrl);
            outputSocket.onopen = () => { appendOutput('[Connected]\n', 'dim'); };
            outputSocket.onmessage = (event) => {
                try {
                    const msg = JSON.parse(event.data);
                    if (msg.type === 'output') appendOutput(msg.data);
                    else if (msg.type === 'complete') handleComplete(msg);
                    else if (msg.type === 'error') { appendOutput('\n[ERROR] ' + msg.message + '\n', 'error'); handleComplete({ status: 'failed' }); }
                } catch (e) { if (event.data !== 'pong') appendOutput(event.data); }
            };
            outputSocket.onclose = () => { if (currentRunId) handleComplete({ status: 'disconnected' }); };
            outputSocket.onerror = () => { appendOutput('\n[WebSocket error]\n', 'error'); currentRunId = null; };
            const pingInterval = setInterval(() => {
                if (outputSocket && outputSocket.readyState === WebSocket.OPEN) outputSocket.send('ping');
                else clearInterval(pingInterval);
            }, 25000);
        } catch (e) { appendOutput('\n[Failed to connect]\n', 'error'); }
    }

    function handleComplete(msg) {
        appendOutput('\n' + '─'.repeat(50) + '\n', 'dim');
        if (msg.status === 'completed') {
            appendOutput('[' + new Date().toLocaleTimeString() + '] ✓ Report completed', 'success');
            if (msg.exit_code !== undefined) appendOutput(' (exit code: ' + msg.exit_code + ')', 'success');
            appendOutput('\n', 'success');
            addLog('Report completed successfully', 'success');
        } else {
            appendOutput('[' + new Date().toLocaleTimeString() + '] ✗ Report ' + msg.status + '\n', 'error');
            addLog('Report ' + msg.status, 'error');
        }
        currentRunId = null;
        if (outputSocket) { outputSocket.close(); outputSocket = null; }
    }

    async function registerReport() {
        const scriptId = document.getElementById('reportId').value.trim();
        const name = document.getElementById('reportName').value.trim();
        const path = document.getElementById('reportPath').value.trim();
        const category = document.getElementById('reportCategory').value.trim() || 'General';
        const timeout = parseInt(document.getElementById('reportTimeout').value) || 300;
        const description = document.getElementById('reportDescription').value.trim();

        if (!scriptId) { addLog('Please enter a Report ID', 'error'); return; }
        if (!path) { addLog('Please enter a Script Path', 'error'); return; }
        if (!/^[a-zA-Z0-9_-]+$/.test(scriptId)) { addLog('Report ID must contain only letters, numbers, hyphens and underscores', 'error'); return; }

        // Collect parameters from visual builder
        const parameters = collectBuilderParameters();

        try {
            const response = await fetch('/api/reports/scripts/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ script_id: scriptId, name: name || scriptId, script_path: path, category: category, timeout: timeout, description: description, parameters: parameters })
            });
            if (!response.ok) { const err = await response.json().catch(() => ({})); throw new Error(err.detail || 'Failed'); }
            addLog('Report "' + scriptId + '" registered' + (parameters.length > 0 ? ' with ' + parameters.length + ' parameter(s)' : ''), 'success');
            document.getElementById('reportId').value = '';
            document.getElementById('reportName').value = '';
            document.getElementById('reportPath').value = '';
            document.getElementById('reportCategory').value = 'General';
            document.getElementById('reportTimeout').value = '300';
            document.getElementById('reportDescription').value = '';
            clearParameterBuilder();
            loadScripts();
        } catch (error) { addLog('Failed to register: ' + error.message, 'error'); }
    }

    function appendOutput(text, className) {
        const panel = document.getElementById('report-output');
        if (!panel) return;
        const placeholder = panel.querySelector('.output-placeholder');
        if (placeholder) placeholder.remove();
        const span = document.createElement('span');
        if (className) span.className = 'output-' + className;
        span.textContent = text;
        panel.appendChild(span);
        panel.scrollTop = panel.scrollHeight;
    }

    function clearOutput() {
        const panel = document.getElementById('report-output');
        if (panel) panel.innerHTML = '<span class="output-placeholder">Output will appear here...</span>';
        // Reset run state in case it got stuck
        currentRunId = null;
        if (outputSocket) { outputSocket.close(); outputSocket = null; }
    }

    function copyOutput() {
        const panel = document.getElementById('report-output');
        if (panel) navigator.clipboard.writeText(panel.textContent).then(() => addLog('Output copied', 'success'));
    }

    function refreshAgents() { renderAgentDropdown(); }

    // Parameter Builder
    let parameterCount = 0;
    
    function addParameter() {
        const builder = document.getElementById('parameterBuilder');
        // Remove empty message if present
        if (parameterCount === 0) {
            builder.innerHTML = '';
        }
        
        const idx = parameterCount++;
        const row = document.createElement('div');
        row.id = 'param-row-' + idx;
        row.style.cssText = 'display: grid; grid-template-columns: 1fr 1fr 120px 80px 1fr auto; gap: 0.5rem; align-items: end; margin-bottom: 0.5rem; padding: 0.5rem; background: var(--slate-bg-90); border-radius: 0.375rem;';
        row.innerHTML = 
            '<div><div style="font-size: 10px; color: var(--text-muted); margin-bottom: 2px;">Name *</div><input type="text" class="form-input" id="pb-name-' + idx + '" placeholder="param_name" style="font-size: 11px;"></div>' +
            '<div><div style="font-size: 10px; color: var(--text-muted); margin-bottom: 2px;">Label</div><input type="text" class="form-input" id="pb-label-' + idx + '" placeholder="Display Label" style="font-size: 11px;"></div>' +
            '<div><div style="font-size: 10px; color: var(--text-muted); margin-bottom: 2px;">Type</div><select class="form-input" id="pb-type-' + idx + '" onchange="ReportsModule.onParamTypeChange(' + idx + ')" style="font-size: 11px;"><option value="text">Text</option><option value="number">Number</option><option value="date">Date</option><option value="select">Select</option><option value="checkbox">Checkbox</option><option value="textarea">Textarea</option></select></div>' +
            '<div><div style="font-size: 10px; color: var(--text-muted); margin-bottom: 2px;">Required</div><label style="display: flex; align-items: center; height: 32px;"><input type="checkbox" id="pb-req-' + idx + '" style="width: 16px; height: 16px; accent-color: var(--sky-400);"></label></div>' +
            '<div id="pb-extra-' + idx + '"><div style="font-size: 10px; color: var(--text-muted); margin-bottom: 2px;">Default</div><input type="text" class="form-input" id="pb-default-' + idx + '" placeholder="default value" style="font-size: 11px;"></div>' +
            '<div><button class="btn" onclick="ReportsModule.removeParameter(' + idx + ')" style="font-size: 10px; padding: 4px 8px; color: var(--rose-200);">✕</button></div>';
        builder.appendChild(row);
    }
    
    function removeParameter(idx) {
        const row = document.getElementById('param-row-' + idx);
        if (row) row.remove();
        // Check if any params left
        const builder = document.getElementById('parameterBuilder');
        if (builder.children.length === 0) {
            builder.innerHTML = '<div style="text-align: center; color: var(--text-muted); font-size: 11px; padding: 0.5rem;">No parameters defined. Click "Add Parameter" to add one.</div>';
            parameterCount = 0;
        }
    }
    
    function onParamTypeChange(idx) {
        const type = document.getElementById('pb-type-' + idx).value;
        const extraDiv = document.getElementById('pb-extra-' + idx);
        
        if (type === 'select') {
            extraDiv.innerHTML = '<div style="font-size: 10px; color: var(--text-muted); margin-bottom: 2px;">Options (comma-sep)</div><input type="text" class="form-input" id="pb-options-' + idx + '" placeholder="PROD,DEV,QA" style="font-size: 11px;">';
        } else if (type === 'number') {
            extraDiv.innerHTML = '<div style="font-size: 10px; color: var(--text-muted); margin-bottom: 2px;">Default / Min / Max</div><div style="display: flex; gap: 4px;"><input type="number" class="form-input" id="pb-default-' + idx + '" placeholder="def" style="font-size: 11px; width: 50px;"><input type="number" class="form-input" id="pb-min-' + idx + '" placeholder="min" style="font-size: 11px; width: 50px;"><input type="number" class="form-input" id="pb-max-' + idx + '" placeholder="max" style="font-size: 11px; width: 50px;"></div>';
        } else if (type === 'checkbox') {
            extraDiv.innerHTML = '<div style="font-size: 10px; color: var(--text-muted); margin-bottom: 2px;">Default</div><label style="display: flex; align-items: center; height: 32px;"><input type="checkbox" id="pb-default-' + idx + '" style="width: 16px; height: 16px; accent-color: var(--sky-400);"><span style="font-size: 11px; margin-left: 6px;">Checked</span></label>';
        } else {
            extraDiv.innerHTML = '<div style="font-size: 10px; color: var(--text-muted); margin-bottom: 2px;">Default</div><input type="text" class="form-input" id="pb-default-' + idx + '" placeholder="default value" style="font-size: 11px;">';
        }
    }
    
    function collectBuilderParameters() {
        const params = [];
        const builder = document.getElementById('parameterBuilder');
        const rows = builder.querySelectorAll('[id^="param-row-"]');
        
        rows.forEach(row => {
            const idx = row.id.replace('param-row-', '');
            const name = document.getElementById('pb-name-' + idx);
            if (!name || !name.value.trim()) return;
            
            const type = document.getElementById('pb-type-' + idx).value;
            const param = {
                name: name.value.trim(),
                label: (document.getElementById('pb-label-' + idx).value.trim()) || name.value.trim(),
                type: type,
                required: document.getElementById('pb-req-' + idx).checked
            };
            
            if (type === 'select') {
                const optEl = document.getElementById('pb-options-' + idx);
                if (optEl && optEl.value.trim()) {
                    param.options = optEl.value.split(',').map(s => s.trim()).filter(s => s);
                }
            } else if (type === 'number') {
                const defEl = document.getElementById('pb-default-' + idx);
                const minEl = document.getElementById('pb-min-' + idx);
                const maxEl = document.getElementById('pb-max-' + idx);
                if (defEl && defEl.value) param.default = parseFloat(defEl.value);
                if (minEl && minEl.value) param.min = parseFloat(minEl.value);
                if (maxEl && maxEl.value) param.max = parseFloat(maxEl.value);
            } else if (type === 'checkbox') {
                const defEl = document.getElementById('pb-default-' + idx);
                if (defEl) param.default = defEl.checked;
            } else {
                const defEl = document.getElementById('pb-default-' + idx);
                if (defEl && defEl.value.trim()) param.default = defEl.value.trim();
            }
            
            params.push(param);
        });
        
        return params;
    }
    
    function clearParameterBuilder() {
        parameterCount = 0;
        document.getElementById('parameterBuilder').innerHTML = '<div style="text-align: center; color: var(--text-muted); font-size: 11px; padding: 0.5rem;">No parameters defined. Click "Add Parameter" to add one.</div>';
    }

    return { init, loadScripts, registerReport, runSelectedReport, quickRun, onReportSelect, clearOutput, copyOutput, refreshAgents, addParameter, removeParameter, onParamTypeChange };
})();
