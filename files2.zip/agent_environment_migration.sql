-- ============================================================================
-- Agent Environment Access Control Migration
-- Run this to add environment-based agent access restrictions
-- ============================================================================

-- 1. Add environment column to agents table
ALTER TABLE agents ADD COLUMN environment VARCHAR(20) DEFAULT 'DEV';

-- 2. Create user_agent_access table for environment permissions
CREATE TABLE IF NOT EXISTS user_agent_access (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    environment VARCHAR(20) NOT NULL,  -- DEV, TEST, PROD, or * for all
    granted_by VARCHAR(255),
    granted_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    UNIQUE(user_id, environment)
);

-- 3. Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_user_agent_access_user_id ON user_agent_access(user_id);
CREATE INDEX IF NOT EXISTS idx_user_agent_access_environment ON user_agent_access(environment);
CREATE INDEX IF NOT EXISTS idx_agents_environment ON agents(environment);

-- 4. Create view for easy user environment queries
CREATE VIEW IF NOT EXISTS v_user_environments AS
SELECT 
    u.user_id,
    u.username,
    u.full_name,
    uaa.environment,
    uaa.granted_by,
    uaa.granted_at
FROM users u
JOIN user_agent_access uaa ON u.user_id = uaa.user_id
ORDER BY u.username, uaa.environment;

-- 5. Grant existing admins access to all environments (migration)
-- This ensures current admins don't lose access
INSERT OR IGNORE INTO user_agent_access (user_id, environment, granted_by)
SELECT DISTINCT
    ur.user_id,
    '*',
    'migration'
FROM user_roles ur
JOIN roles r ON ur.role_id = r.role_id
WHERE r.role_name = 'admin';

-- ============================================================================
-- Helper queries (run these manually as needed)
-- ============================================================================

-- Grant a user access to specific environments:
-- INSERT INTO user_agent_access (user_id, environment, granted_by) 
-- SELECT user_id, 'DEV', 'admin' FROM users WHERE username = 'jsmith';
-- INSERT INTO user_agent_access (user_id, environment, granted_by) 
-- SELECT user_id, 'TEST', 'admin' FROM users WHERE username = 'jsmith';

-- Grant a user access to ALL environments (superadmin):
-- INSERT INTO user_agent_access (user_id, environment, granted_by) 
-- SELECT user_id, '*', 'admin' FROM users WHERE username = 'jsmith';

-- Remove a user's access to an environment:
-- DELETE FROM user_agent_access 
-- WHERE user_id = (SELECT user_id FROM users WHERE username = 'jsmith')
-- AND environment = 'PROD';

-- Get all environments a user can access:
-- SELECT environment FROM user_agent_access 
-- WHERE user_id = (SELECT user_id FROM users WHERE username = 'jsmith');

-- Get all users with access to PROD:
-- SELECT u.username, u.full_name FROM users u
-- JOIN user_agent_access uaa ON u.user_id = uaa.user_id
-- WHERE uaa.environment IN ('PROD', '*');

-- Update an agent's environment:
-- UPDATE agents SET environment = 'PROD' WHERE agent_name = 'prod-server-1';

-- List agents by environment:
-- SELECT agent_name, host, port, environment FROM agents ORDER BY environment, agent_name;

-- ============================================================================
-- Sample data for testing (optional - comment out in production)
-- ============================================================================

-- Update existing agents with environments (customize as needed):
-- UPDATE agents SET environment = 'DEV' WHERE agent_name LIKE '%dev%';
-- UPDATE agents SET environment = 'TEST' WHERE agent_name LIKE '%test%' OR agent_name LIKE '%qa%';
-- UPDATE agents SET environment = 'PROD' WHERE agent_name LIKE '%prod%';
