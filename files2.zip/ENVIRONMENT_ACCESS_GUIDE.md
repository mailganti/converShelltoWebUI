# Agent Environment Access Control - Deployment Guide

## Overview

This update adds environment-based access control to agents. Admins can now be restricted to specific environments (DEV, TEST, PROD) instead of having access to all agents.

## Files Included

| File | Purpose |
|------|---------|
| `agent_environment_migration.sql` | Database schema changes |
| `agents.py` | Updated routes with filtering |
| `db_methods_to_add.py` | New db.py methods required |

## Deployment Steps

### 1. Backup Database
```bash
cp orchestration.db orchestration.db.backup
```

### 2. Run Migration
```bash
sqlite3 orchestration.db < agent_environment_migration.sql
```

### 3. Add Database Methods
Add the methods from `db_methods_to_add.py` to your `controller/db/db.py` class.

### 4. Replace agents.py
```bash
cp agents.py controller/routes/agents.py
```

### 5. Update Existing Agents with Environments
```sql
-- Set environment based on naming convention (customize as needed)
UPDATE agents SET environment = 'DEV' WHERE agent_name LIKE '%dev%';
UPDATE agents SET environment = 'TEST' WHERE agent_name LIKE '%test%' OR agent_name LIKE '%qa%';
UPDATE agents SET environment = 'PROD' WHERE agent_name LIKE '%prod%';

-- Or set specific agents manually
UPDATE agents SET environment = 'PROD' WHERE agent_name = 'prod-server-1';
```

### 6. Grant User Access
```sql
-- Grant specific environments
INSERT INTO user_agent_access (user_id, environment, granted_by) 
SELECT user_id, 'DEV', 'admin' FROM users WHERE username = 'dev_admin';

INSERT INTO user_agent_access (user_id, environment, granted_by) 
SELECT user_id, 'TEST', 'admin' FROM users WHERE username = 'dev_admin';

-- Grant superadmin access (all environments)
INSERT INTO user_agent_access (user_id, environment, granted_by) 
SELECT user_id, '*', 'admin' FROM users WHERE username = 'super_admin';
```

### 7. Restart Services
```bash
systemctl restart orchestration-controller
# or
supervisorctl restart controller
```

## New API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/agents/environments` | GET | List valid environments + user's access |
| `/api/agents/access/users` | GET | List all user environment access (admin) |
| `/api/agents/access/grant` | POST | Grant environment access (admin) |
| `/api/agents/access/revoke` | DELETE | Revoke environment access (admin) |

## API Usage Examples

### List Agents (now filtered)
```bash
# User only sees agents in their allowed environments
curl -H "Authorization: Bearer $TOKEN" https://host/api/agents/

# Filter by specific environment
curl -H "Authorization: Bearer $TOKEN" https://host/api/agents/?environment=PROD
```

### Register Agent with Environment
```bash
curl -X POST https://host/api/agents/ \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "agent_name": "prod-db-1",
    "host": "10.0.1.50",
    "port": 8001,
    "environment": "PROD"
  }'
```

### Grant Environment Access
```bash
curl -X POST https://host/api/agents/access/grant \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "jsmith",
    "environment": "DEV"
  }'
```

### Revoke Environment Access
```bash
curl -X DELETE https://host/api/agents/access/revoke \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "jsmith",
    "environment": "PROD"
  }'
```

## Behavior Summary

| Action | Requirement |
|--------|-------------|
| List agents | Only sees agents in allowed environments |
| View agent details | Must have access to agent's environment |
| Register agent | Must have access to target environment |
| Update agent | Must have access to current (and new) environment |
| Delete agent | Must have access to agent's environment |
| Ping agent | Must have access to agent's environment |
| Grant access | Must have access to environment (or be superadmin) |
| Grant `*` access | Must already be superadmin |

## Answers to Your Earlier Questions

1. **Granularity**: Environment-level (DEV/TEST/PROD)
2. **Storage**: Separate mapping table (`user_agent_access`)
3. **Superadmin**: `environment = '*'` grants access to all
4. **Default behavior**: NULL/empty = no access (secure by default)

## Migration Auto-Grants

The migration automatically grants `*` (all environments) to existing users with the `admin` role, so current admins won't lose access.

## Rollback

If needed, rollback by restoring the backup:
```bash
cp orchestration.db.backup orchestration.db
cp agents.py.backup controller/routes/agents.py
systemctl restart orchestration-controller
```
