/**
 * Reports Module
 * ==============
 * Run status scripts without approval workflow
 */

const ReportsModule = (function() {
    'use strict';

    // State
    let scripts = [];
    let selectedScript = null;
    let currentRunId = null;
    let outputSocket = null;
    let history = [];
    let initialized = false;

    // DOM Elements
    let container = null;

    // ========================================================================
    // Initialization
    // ========================================================================

    function init(containerId = 'tab-reports') {
        container = document.getElementById(containerId);
        if (!container) {
            console.error('Reports container not found:', containerId);
            return;
        }

        // Only initialize once
        if (initialized && container.innerHTML.includes('reports-layout')) {
            return;
        }

        render();
        loadScripts();
        loadHistory();
        initialized = true;
    }

    function render() {
        container.innerHTML = `
            <div class="reports-layout">
                <!-- Left Panel: Script List -->
                <div class="reports-sidebar">
                    <div class="reports-header">
                        <div class="section-title">📊 Report Scripts</div>
                        <button class="btn" onclick="ReportsModule.loadScripts()">Refresh</button>
                    </div>
                    <div class="reports-search">
                        <input type="text" class="form-input" id="report-search" placeholder="Search reports..." 
                               onkeyup="ReportsModule.filterScripts(this.value)">
                    </div>
                    <div class="reports-categories" id="reports-categories"></div>
                    <div class="reports-list" id="reports-list">
                        <div class="empty-row">Loading scripts...</div>
                    </div>
                </div>

                <!-- Right Panel: Details & Output -->
                <div class="reports-main">
                    <!-- Script Details -->
                    <div class="reports-details" id="report-details">
                        <div class="no-selection">
                            <div class="no-selection-icon">📋</div>
                            <p>Select a report script to view details</p>
                        </div>
                    </div>

                    <!-- Output Panel -->
                    <div class="reports-output">
                        <div class="section-header">
                            <div class="section-title">Output</div>
                            <div class="output-controls">
                                <button class="btn" onclick="ReportsModule.clearOutput()">Clear</button>
                                <button class="btn" onclick="ReportsModule.copyOutput()">Copy</button>
                                <button class="btn" onclick="ReportsModule.downloadOutput()">⬇ Download</button>
                            </div>
                        </div>
                        <div class="output-content" id="report-output">
                            <div class="output-placeholder">Output will appear here when you run a report</div>
                        </div>
                    </div>

                    <!-- History Panel -->
                    <div class="reports-history">
                        <div class="section-header">
                            <div class="section-title">Recent Runs</div>
                            <button class="btn" onclick="ReportsModule.loadHistory()">Refresh</button>
                        </div>
                        <div class="history-list" id="history-list">
                            <div class="empty-row">No recent runs</div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // ========================================================================
    // API Calls
    // ========================================================================

    async function loadScripts() {
        try {
            const response = await fetch('/api/reports/scripts');
            if (!response.ok) throw new Error('Failed to load scripts');
            
            scripts = await response.json();
            renderScriptsList();
            
            // Update tab badge
            const badge = document.getElementById('tabBadgeReports');
            if (badge) badge.textContent = scripts.length;
            
        } catch (error) {
            console.error('Error loading scripts:', error);
            document.getElementById('reports-list').innerHTML = 
                '<div class="empty-row">Failed to load scripts. Check if reports API is enabled.</div>';
        }
    }

    async function loadHistory() {
        try {
            const response = await fetch('/api/reports/history?limit=10');
            if (!response.ok) throw new Error('Failed to load history');
            
            history = await response.json();
            renderHistory();
        } catch (error) {
            console.error('Error loading history:', error);
        }
    }

    async function runScript(scriptId) {
        if (currentRunId) {
            showToast('A report is already running', 'warning');
            return;
        }

        try {
            clearOutput();
            appendOutput(`[${new Date().toLocaleTimeString()}] Starting report...\n`, 'info');
            updateRunButton(true);

            const response = await fetch(`/api/reports/run/${scriptId}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ parameters: {} })
            });

            if (!response.ok) throw new Error('Failed to start report');

            const result = await response.json();
            currentRunId = result.run_id;

            appendOutput(`[${new Date().toLocaleTimeString()}] Run ID: ${currentRunId}\n`, 'info');
            appendOutput(`${'─'.repeat(60)}\n`, 'dim');

            connectToOutputStream(currentRunId);

        } catch (error) {
            console.error('Error running script:', error);
            showToast('Failed to run report: ' + error.message, 'error');
            updateRunButton(false);
        }
    }

    async function cancelReport() {
        if (!currentRunId) return;

        try {
            await fetch(`/api/reports/result/${currentRunId}`, { method: 'DELETE' });
            appendOutput('\n[Cancelled by user]\n', 'error');
        } catch (error) {
            console.error('Error cancelling report:', error);
        }
    }

    // ========================================================================
    // WebSocket Connection
    // ========================================================================

    function connectToOutputStream(runId) {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//${window.location.host}/api/reports/ws/${runId}`;

        outputSocket = new WebSocket(wsUrl);

        outputSocket.onopen = () => {
            console.log('Connected to report output stream');
        };

        outputSocket.onmessage = (event) => {
            try {
                const msg = JSON.parse(event.data);
                
                if (msg.type === 'output') {
                    appendOutput(msg.data);
                } else if (msg.type === 'complete') {
                    handleReportComplete(msg);
                } else if (msg.type === 'error') {
                    appendOutput(`\n[ERROR] ${msg.message}\n`, 'error');
                    handleReportComplete({ status: 'failed' });
                }
            } catch (e) {
                if (event.data !== 'pong' && event.data !== 'ping') {
                    appendOutput(event.data);
                }
            }
        };

        outputSocket.onclose = () => {
            console.log('Disconnected from report output stream');
            if (currentRunId) {
                handleReportComplete({ status: 'disconnected' });
            }
        };

        outputSocket.onerror = (error) => {
            console.error('WebSocket error:', error);
            appendOutput('\n[Connection error]\n', 'error');
        };

        const pingInterval = setInterval(() => {
            if (outputSocket && outputSocket.readyState === WebSocket.OPEN) {
                outputSocket.send('ping');
            } else {
                clearInterval(pingInterval);
            }
        }, 25000);
    }

    function handleReportComplete(msg) {
        const status = msg.status;
        const exitCode = msg.exit_code;

        appendOutput(`\n${'─'.repeat(60)}\n`, 'dim');
        
        if (status === 'completed') {
            appendOutput(`[${new Date().toLocaleTimeString()}] ✓ Report completed (exit code: ${exitCode})\n`, 'success');
        } else if (status === 'failed') {
            appendOutput(`[${new Date().toLocaleTimeString()}] ✗ Report failed (exit code: ${exitCode})\n`, 'error');
        } else if (status === 'cancelled') {
            appendOutput(`[${new Date().toLocaleTimeString()}] ⊘ Report cancelled\n`, 'warning');
        } else {
            appendOutput(`[${new Date().toLocaleTimeString()}] Report ended: ${status}\n`, 'info');
        }

        currentRunId = null;
        updateRunButton(false);
        
        if (outputSocket) {
            outputSocket.close();
            outputSocket = null;
        }

        setTimeout(loadHistory, 1000);
    }

    // ========================================================================
    // Rendering
    // ========================================================================

    function renderScriptsList(filter = '') {
        const categories = {};
        const filterLower = filter.toLowerCase();

        scripts.forEach(script => {
            if (filter && !script.name.toLowerCase().includes(filterLower) &&
                !script.description.toLowerCase().includes(filterLower)) {
                return;
            }

            if (!categories[script.category]) {
                categories[script.category] = [];
            }
            categories[script.category].push(script);
        });

        // Render categories
        const categoriesHtml = Object.keys(categories).sort().map(cat => 
            `<button class="filter-btn" onclick="ReportsModule.filterByCategory('${cat}')">${cat}</button>`
        ).join('');
        
        document.getElementById('reports-categories').innerHTML = 
            `<button class="filter-btn active" onclick="ReportsModule.filterByCategory('')">All</button>` + 
            categoriesHtml;

        // Render scripts
        const listEl = document.getElementById('reports-list');
        
        if (Object.keys(categories).length === 0) {
            listEl.innerHTML = '<div class="empty-row">No report scripts found</div>';
            return;
        }

        let html = '';
        Object.keys(categories).sort().forEach(category => {
            html += `<div class="script-category-header">${category}</div>`;
            categories[category].forEach(script => {
                const isSelected = selectedScript && selectedScript.id === script.id;
                html += `
                    <div class="script-item ${isSelected ? 'selected' : ''}" 
                         onclick="ReportsModule.selectScript('${script.id}')">
                        <div class="script-name">${escapeHtml(script.name)}</div>
                        <div class="script-desc">${escapeHtml(script.description)}</div>
                        ${script.estimated_time ? `<div class="script-time">⏱ ${script.estimated_time}</div>` : ''}
                    </div>
                `;
            });
        });

        listEl.innerHTML = html;
    }

    function selectScript(scriptId) {
        selectedScript = scripts.find(s => s.id === scriptId);
        if (!selectedScript) return;

        // Update selection in list
        document.querySelectorAll('.script-item').forEach(el => el.classList.remove('selected'));
        document.querySelectorAll('.script-item').forEach(el => {
            if (el.onclick.toString().includes(scriptId)) {
                el.classList.add('selected');
            }
        });

        // Show details
        const detailsPanel = document.getElementById('report-details');
        detailsPanel.innerHTML = `
            <div class="details-content">
                <div class="section-title" style="font-size: 16px; margin-bottom: 0.5rem;">${escapeHtml(selectedScript.name)}</div>
                <p style="color: var(--text-secondary); margin-bottom: 1rem;">${escapeHtml(selectedScript.description)}</p>
                
                <div class="kpi-row" style="margin-bottom: 1rem;">
                    <div class="kpi-card">
                        <div class="kpi-label">Category</div>
                        <div class="kpi-value" style="font-size: 12px;">${escapeHtml(selectedScript.category)}</div>
                    </div>
                    <div class="kpi-card">
                        <div class="kpi-label">File</div>
                        <div class="kpi-value" style="font-size: 12px; font-family: monospace;">${escapeHtml(selectedScript.filename)}</div>
                    </div>
                    ${selectedScript.estimated_time ? `
                    <div class="kpi-card">
                        <div class="kpi-label">Est. Time</div>
                        <div class="kpi-value" style="font-size: 12px;">${escapeHtml(selectedScript.estimated_time)}</div>
                    </div>
                    ` : ''}
                </div>

                <button class="btn btn-primary" id="run-button" onclick="ReportsModule.runScript('${selectedScript.id}')">
                    ▶ Run Report
                </button>
            </div>
        `;
    }

    function renderHistory() {
        const historyList = document.getElementById('history-list');
        if (!history || history.length === 0) {
            historyList.innerHTML = '<div class="empty-row">No recent runs</div>';
            return;
        }

        historyList.innerHTML = history.map(run => {
            const statusClass = run.status === 'completed' ? 'badge-executed' : 
                               run.status === 'failed' ? 'badge-failed' : 'badge-executing';
            const statusIcon = run.status === 'completed' ? '✓' : 
                              run.status === 'failed' ? '✗' : '⋯';
            
            return `
                <div class="history-item" onclick="ReportsModule.showHistoryRun('${run.run_id}')">
                    <span class="badge ${statusClass}" style="margin-right: 8px;">${statusIcon}</span>
                    <span style="flex: 1; font-family: monospace; font-size: 11px;">${escapeHtml(run.script_id.split('__').pop())}</span>
                    <span style="font-size: 10px; color: var(--text-muted);">${formatTime(run.started_at)}</span>
                </div>
            `;
        }).join('');
    }

    async function showHistoryRun(runId) {
        try {
            const response = await fetch(`/api/reports/result/${runId}`);
            if (!response.ok) throw new Error('Failed to load result');
            
            const result = await response.json();
            
            clearOutput();
            appendOutput(`[History] Run: ${result.run_id}\n`, 'info');
            appendOutput(`[History] Status: ${result.status}\n`, 'info');
            appendOutput(`[History] Started: ${formatDate(result.started_at)}\n`, 'info');
            if (result.completed_at) {
                appendOutput(`[History] Completed: ${formatDate(result.completed_at)}\n`, 'info');
            }
            appendOutput(`${'─'.repeat(60)}\n`, 'dim');
            
            if (result.output) {
                appendOutput(result.output);
            }
        } catch (error) {
            console.error('Error loading history run:', error);
            showToast('Failed to load run details', 'error');
        }
    }

    // ========================================================================
    // Output Handling
    // ========================================================================

    function appendOutput(text, className = '') {
        const outputPanel = document.getElementById('report-output');
        const placeholder = outputPanel.querySelector('.output-placeholder');
        if (placeholder) placeholder.remove();

        const span = document.createElement('span');
        if (className) span.className = `output-${className}`;
        span.textContent = text;
        outputPanel.appendChild(span);

        outputPanel.scrollTop = outputPanel.scrollHeight;
    }

    function clearOutput() {
        document.getElementById('report-output').innerHTML = '';
    }

    function copyOutput() {
        const text = document.getElementById('report-output').textContent;
        navigator.clipboard.writeText(text).then(() => {
            showToast('Output copied to clipboard', 'success');
        }).catch(err => {
            console.error('Failed to copy:', err);
        });
    }

    function downloadOutput() {
        const text = document.getElementById('report-output').textContent;
        const blob = new Blob([text], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `report_output_${new Date().toISOString().slice(0,19).replace(/[:-]/g,'')}.txt`;
        a.click();
        URL.revokeObjectURL(url);
    }

    // ========================================================================
    // UI Helpers
    // ========================================================================

    function updateRunButton(running) {
        const runButton = document.getElementById('run-button');
        if (!runButton) return;
        
        if (running) {
            runButton.textContent = '⏹ Cancel';
            runButton.classList.remove('btn-primary');
            runButton.classList.add('action-btn-danger');
            runButton.onclick = cancelReport;
        } else {
            runButton.textContent = '▶ Run Report';
            runButton.classList.add('btn-primary');
            runButton.classList.remove('action-btn-danger');
            if (selectedScript) {
                runButton.onclick = () => runScript(selectedScript.id);
            }
        }
    }

    function filterScripts(filter) {
        renderScriptsList(filter);
    }

    function filterByCategory(category) {
        document.querySelectorAll('#reports-categories .filter-btn').forEach(btn => {
            btn.classList.toggle('active', btn.textContent === (category || 'All'));
        });

        if (!category) {
            renderScriptsList();
            return;
        }

        const filtered = scripts.filter(s => s.category === category);
        const listEl = document.getElementById('reports-list');
        
        let html = `<div class="script-category-header">${category}</div>`;
        filtered.forEach(script => {
            html += `
                <div class="script-item" onclick="ReportsModule.selectScript('${script.id}')">
                    <div class="script-name">${escapeHtml(script.name)}</div>
                    <div class="script-desc">${escapeHtml(script.description)}</div>
                </div>
            `;
        });

        listEl.innerHTML = html;
    }

    function showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;
        document.body.appendChild(toast);
        
        setTimeout(() => toast.classList.add('show'), 10);
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    // ========================================================================
    // Utilities
    // ========================================================================

    function escapeHtml(str) {
        if (!str) return '';
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

    function formatDate(isoString) {
        if (!isoString) return '';
        return new Date(isoString).toLocaleString();
    }

    function formatTime(isoString) {
        if (!isoString) return '';
        return new Date(isoString).toLocaleTimeString();
    }

    // ========================================================================
    // Public API
    // ========================================================================

    return {
        init,
        loadScripts,
        loadHistory,
        selectScript,
        runScript,
        filterScripts,
        filterByCategory,
        showHistoryRun,
        clearOutput,
        copyOutput,
        downloadOutput,
    };

})();
