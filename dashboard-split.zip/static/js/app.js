/**
 * Orchestration Dashboard - Main Application
 * ===========================================
 */

const API_BASE = '/api';

// State
let currentUser = null;
let workflows = [];
let agents = [];
let scripts = [];
let approvers = [];
let selectedAgents = [];
let logs = [];
let logfiles = {};
let selectedWorkflow = null;
let logsExpanded = true;
let loading = false;
let currentTab = 'workflows';
let workflowFilter = 'all';
let agentFilter = 'all';
let refreshCountdown = 30;
let countdownInterval = null;
let activityFooterExpanded = true;
let pendingDenyWorkflowId = null;

// ==========================================================================
// Tab Management
// ==========================================================================

function switchTab(tabName) {
    currentTab = tabName;
    
    // Update tab buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
        const isActive = btn.id === `tabBtn${tabName.charAt(0).toUpperCase() + tabName.slice(1)}`;
        btn.classList.toggle('active', isActive);
    });
    
    // Update tab content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.toggle('active', content.id === `tab-${tabName}`);
    });
    
    // Initialize Reports tab if selected
    if (tabName === 'reports' && typeof ReportsModule !== 'undefined') {
        ReportsModule.init('reports-container');
    }
}

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Don't trigger if typing in an input
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') return;
    
    if (e.key === '1') switchTab('workflows');
    else if (e.key === '2' && hasRole('admin')) switchTab('agents');
    else if (e.key === '3' && hasRole('admin')) switchTab('scripts');
    else if (e.key === '4') switchTab('reports');
    else if (e.key === 'r' || e.key === 'R') { loadData(); loadScripts(); }
});

// ==========================================================================
// Activity Footer
// ==========================================================================

function toggleActivityFooter() {
    activityFooterExpanded = !activityFooterExpanded;
    document.getElementById('activityFooter').classList.toggle('collapsed', !activityFooterExpanded);
    document.getElementById('footerSpacer').classList.toggle('collapsed', !activityFooterExpanded);
    document.getElementById('footerToggle').textContent = activityFooterExpanded ? '▼ Click to collapse' : '▲ Click to expand';
}

// ==========================================================================
// Filters
// ==========================================================================

function filterWorkflows(status) {
    workflowFilter = status;
    document.querySelectorAll('#tab-workflows .filter-btn').forEach(btn => {
        btn.classList.toggle('active', btn.textContent.toLowerCase().includes(status) || (status === 'all' && btn.textContent === 'All'));
    });
    renderWorkflows();
}

function filterAgents(status) {
    agentFilter = status;
    document.querySelectorAll('#tab-agents .filter-btn').forEach(btn => {
        btn.classList.toggle('active', btn.textContent.toLowerCase() === status);
    });
    renderAgents();
}

// ==========================================================================
// Auto-refresh
// ==========================================================================

function startCountdown() {
    if (countdownInterval) clearInterval(countdownInterval);
    refreshCountdown = 30;
    updateCountdownDisplay();
    countdownInterval = setInterval(() => {
        refreshCountdown--;
        updateCountdownDisplay();
        if (refreshCountdown <= 0) {
            loadData();
            refreshCountdown = 30;
        }
    }, 1000);
}

function updateCountdownDisplay() {
    const el = document.getElementById('refreshCountdown');
    if (el) el.textContent = refreshCountdown;
}

function updateTabBadges() {
    const pendingCount = workflows.filter(w => w.status === 'pending').length;
    const onlineAgents = agents.filter(a => a.status === 'online').length;
    
    document.getElementById('tabBadgeWorkflows').textContent = workflows.length;
    document.getElementById('tabBadgeWorkflows').classList.toggle('pending', pendingCount > 0);
    if (pendingCount > 0) {
        document.getElementById('tabBadgeWorkflows').textContent = `${pendingCount} pending`;
    }
    
    document.getElementById('tabBadgeAgents').textContent = agents.length > 0 ? `${onlineAgents}/${agents.length}` : '0';
    document.getElementById('tabBadgeScripts').textContent = scripts.length;
}

// ==========================================================================
// KPI Updates
// ==========================================================================

function updateKPIs() {
    document.getElementById('kpiTotal').textContent = workflows.length;
    document.getElementById('kpiPending').textContent = workflows.filter(w => w.status === 'pending').length;
    document.getElementById('kpiApproved').textContent = workflows.filter(w => w.status === 'approved').length;
    document.getElementById('kpiExecuted').textContent = workflows.filter(w => w.status === 'executed').length;
}

function updateAgentsKPIs() {
    const total = agents.length;
    const online = agents.filter(a => a.status === 'online').length;
    const offline = total - online;
    
    document.getElementById('kpiAgentsTotal').textContent = total;
    document.getElementById('kpiAgentsOnline').textContent = online;
    document.getElementById('kpiAgentsOffline').textContent = offline;
}

function updateScriptsKPIs() {
    const total = scripts.length;
    const avgTimeout = total > 0 
        ? Math.round(scripts.reduce((sum, s) => sum + (s.timeout || 300), 0) / total)
        : 0;
    
    document.getElementById('kpiScriptsTotal').textContent = total;
    document.getElementById('kpiScriptsTimeout').textContent = `${avgTimeout}s`;
}

// ==========================================================================
// Initialization
// ==========================================================================

document.addEventListener('DOMContentLoaded', () => { 
    loadUserInfo(); 
    loadScripts(); 
    loadApprovers(); 
    loadData(); 
    startCountdown();
});

// ==========================================================================
// Authentication & Roles
// ==========================================================================

async function loadUserInfo() {
    try {
        const res = await fetch('/whoami', { credentials: 'include' });
        if (res.ok) {
            const data = await res.json();
            if (data.logged_in && data.user) {
                currentUser = data.user;
                const displayName = data.user.full_name || data.user.username || 'Unknown User';
                document.getElementById('userName').textContent = displayName;
                const method = data.user.auth_method || 'smartcard';
                const methodLabels = { 'smartcard': '🔐 Smart Card', 'cert': '🔐 Smart Card', 'wna': '🪟 Windows Auth', 'password': '🔑 Password' };
                document.getElementById('authMethod').textContent = methodLabels[method] || method;
                document.getElementById('wfRequestor').value = data.user.username || displayName;
                if (data.user.email) {
                    document.getElementById('wfRequestorEmail').value = data.user.email;
                }
                applyRoleVisibility();
                addLog(`Authenticated as ${displayName} (${currentUser.role || 'user'})`, 'success');
            } else {
                window.location.href = '/login.html';
            }
        } else {
            window.location.href = '/login.html';
        }
    } catch (err) {
        document.getElementById('userName').textContent = 'Auth Error';
        document.getElementById('authMethod').textContent = 'Connection Failed';
        addLog(`Authentication error: ${err.message}`, 'error');
    }
}

function hasRole(...roles) {
    if (!currentUser) return false;
    const userRole = (currentUser.role || 'user').toLowerCase();
    if (userRole === 'admin') return true;
    return roles.map(r => r.toLowerCase()).includes(userRole);
}

function applyRoleVisibility() {
    const userRole = (currentUser?.role || 'user').toLowerCase();
    
    const roleBadge = document.getElementById('userRole');
    if (roleBadge) {
        roleBadge.textContent = userRole;
        roleBadge.className = `user-role-badge ${userRole}`;
    }
    
    const agentsTab = document.getElementById('tabBtnAgents');
    if (agentsTab) {
        agentsTab.style.display = hasRole('admin') ? '' : 'none';
    }
    
    const scriptsTab = document.getElementById('tabBtnScripts');
    if (scriptsTab) {
        scriptsTab.style.display = hasRole('admin') ? '' : 'none';
    }
    
    const activityFooter = document.getElementById('activityFooter');
    const footerSpacer = document.getElementById('footerSpacer');
    if (activityFooter) {
        const canSeeLog = hasRole('admin', 'approver', 'operator');
        activityFooter.style.display = canSeeLog ? '' : 'none';
        if (footerSpacer) footerSpacer.style.display = canSeeLog ? '' : 'none';
    }
    
    updateKeyboardHints();
    
    if (currentTab === 'agents' && !hasRole('admin')) switchTab('workflows');
    if (currentTab === 'scripts' && !hasRole('admin')) switchTab('workflows');
    
    addLog(`Role permissions applied: ${userRole}`, 'info');
}

function updateKeyboardHints() {
    const agentsKbd = document.querySelector('#tabBtnAgents .kbd');
    const scriptsKbd = document.querySelector('#tabBtnScripts .kbd');
    
    if (agentsKbd && !hasRole('admin')) agentsKbd.style.display = 'none';
    if (scriptsKbd && !hasRole('admin')) scriptsKbd.style.display = 'none';
}

// ==========================================================================
// API Helper
// ==========================================================================

async function apiCall(endpoint, options = {}) {
    const url = endpoint.startsWith('/api') ? endpoint : `${API_BASE}${endpoint}`;
    try {
        const res = await fetch(url, { 
            ...options, 
            headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }, 
            credentials: 'include' 
        });
        if (!res.ok) { 
            const err = await res.json().catch(() => ({ detail: 'Unknown error' })); 
            throw new Error(err.detail || `HTTP ${res.status}`); 
        }
        return await res.json();
    } catch (err) { 
        addLog(`API Error: ${err.message}`, 'error'); 
        throw err; 
    }
}

// ==========================================================================
// Data Loading
// ==========================================================================

async function loadData() {
    if (loading) return;
    loading = true;
    document.getElementById('refreshBtn').classList.add('spinning');
    addLog('Loading data...');
    try {
        const [wfResp, agResp] = await Promise.all([
            apiCall('/workflows').catch(() => ({ workflows: [] })), 
            apiCall('/agents/').catch(() => ({ agents: [] }))
        ]);
        workflows = Array.isArray(wfResp) ? wfResp : wfResp.workflows || [];
        agents = Array.isArray(agResp) ? agResp : agResp.agents || [];
        renderWorkflows(); 
        renderAgents(); 
        updateKPIs(); 
        updateAgentsKPIs(); 
        updateTabBadges();
        refreshCountdown = 30;
        addLog('Data loaded successfully', 'success');
    } catch (err) { 
        addLog(`Failed to load data: ${err.message}`, 'error'); 
    } finally { 
        loading = false; 
        document.getElementById('refreshBtn').classList.remove('spinning'); 
    }
}

async function loadScripts() {
    try {
        const res = await fetch(`${API_BASE}/scripts`, { credentials: 'include' });
        if (res.ok) {
            const data = await res.json();
            scripts = data.scripts || [];
            renderScriptDropdown();
            renderScriptsTable();
            updateTabBadges();
            updateScriptsKPIs();
            addLog(`Loaded ${scripts.length} scripts`, 'success');
        }
    } catch (err) {
        addLog(`Failed to load scripts: ${err.message}`, 'error');
        renderScriptDropdown();
        renderScriptsTable();
    }
}

async function loadApprovers() {
    try {
        const res = await fetch(`${API_BASE}/users/approvers`, { credentials: 'include' });
        if (res.ok) {
            const data = await res.json();
            approvers = data.approvers || [];
            renderApproverDropdown();
            addLog(`Loaded ${approvers.length} approvers`, 'success');
        } else {
            renderApproverDropdown();
        }
    } catch (err) {
        addLog(`Could not load approvers: ${err.message}`, 'info');
        renderApproverDropdown();
    }
}

// ==========================================================================
// Rendering
// ==========================================================================

function renderWorkflows() {
    const tbody = document.getElementById('workflowsTable');
    const filtered = workflowFilter === 'all' ? workflows : workflows.filter(w => w.status === workflowFilter);
    
    if (filtered.length === 0) { 
        tbody.innerHTML = `<tr><td colspan="5" class="empty-row">${workflowFilter === 'all' ? 'No workflows found' : `No ${workflowFilter} workflows`}</td></tr>`; 
        return; 
    }
    
    tbody.innerHTML = filtered.map(wf => {
        const isSelected = wf.workflow_id === selectedWorkflow;
        const hasLogs = logfiles[wf.workflow_id];
        return `<tr class="${isSelected ? 'selected' : ''}" onclick="selectWorkflow('${wf.workflow_id}')">
            <td>${escapeHtml(wf.workflow_id)}</td>
            <td><span class="script-badge">${escapeHtml(wf.script_id)}</span></td>
            <td><span class="badge badge-${wf.status}">${wf.status}</span></td>
            <td style="font-size: 11px; color: var(--text-secondary);">${formatDate(wf.created_at)}</td>
            <td class="text-right">
                ${hasLogs ? `<span class="badge badge-logs" style="cursor:pointer;" onclick="event.stopPropagation(); openWorkflowLog('${wf.workflow_id}')">Logs</span>` : ''}
                ${wf.status === 'pending' ? `
                    <button class="action-btn action-btn-secondary" onclick="event.stopPropagation(); approveWorkflow('${wf.workflow_id}')">Approve</button>
                    <button class="action-btn action-btn-danger" onclick="event.stopPropagation(); denyWorkflow('${wf.workflow_id}')">Deny</button>
                ` : ''}
                ${wf.status === 'approved' ? `<button class="action-btn action-btn-primary" onclick="event.stopPropagation(); executeWorkflow('${wf.workflow_id}')">Execute</button>` : ''}
                ${wf.status === 'executing' ? `<span class="badge badge-executing">⏳ Running...</span>` : ''}
                ${wf.status === 'executed' ? `<span class="badge badge-executed">✓ Completed</span>` : ''}
                ${wf.status === 'failed' ? `<span class="badge badge-failed">✗ Failed</span>` : ''}
                ${wf.status === 'denied' ? `<span class="badge badge-denied">Denied</span>` : ''}
            </td></tr>`;
    }).join('');
}

function renderAgents() {
    const tbody = document.getElementById('agentsTable');
    const selector = document.getElementById('agentSelector');
    const filtered = agentFilter === 'all' ? agents : agents.filter(a => a.status === agentFilter);
    
    if (agents.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="empty-row">No agents registered</td></tr>';
        selector.innerHTML = '<div style="padding: 0.25rem; text-align: center; color: var(--text-secondary); font-size: 11px;">No agents registered. Register an agent first →</div>';
        return;
    }
    
    if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" class="empty-row">No ${agentFilter} agents</td></tr>`;
    } else {
        tbody.innerHTML = filtered.map(a => `
            <tr>
                <td>${escapeHtml(a.agent_name)}</td>
                <td>${escapeHtml(a.host)}</td>
                <td>${a.port}</td>
                <td><span class="badge badge-${a.status === 'online' ? 'online' : 'offline'}">${a.status}</span></td>
                <td style="font-size: 11px; color: var(--text-secondary);">${formatDate(a.last_seen)}</td>
            </tr>
        `).join('');
    }
    
    selector.innerHTML = agents.map(a => `
        <label class="agent-option">
            <input type="checkbox" value="${escapeHtml(a.agent_name)}" 
                   ${selectedAgents.includes(a.agent_name) ? 'checked' : ''} 
                   onchange="toggleAgentSelection('${escapeHtml(a.agent_name)}', this.checked)">
            <span class="agent-option-name">${escapeHtml(a.agent_name)}</span>
            <span class="agent-option-status ${a.status}">${a.status}</span>
        </label>
    `).join('');
}

function renderScriptDropdown() {
    const select = document.getElementById('wfScriptId');
    if (scripts.length === 0) {
        select.innerHTML = '<option value="">No scripts registered</option>';
        return;
    }
    select.innerHTML = '<option value="">-- Select a script --</option>' + 
        scripts.map(s => `<option value="${escapeHtml(s.script_id)}" title="${escapeHtml(s.description || '')}">${escapeHtml(s.script_id)}${s.description ? ' - ' + escapeHtml(s.description.substring(0, 30)) : ''}</option>`).join('');
}

function renderScriptsTable() {
    const tbody = document.getElementById('scriptsTable');
    if (scripts.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="empty-row">No scripts registered</td></tr>';
        return;
    }
    tbody.innerHTML = scripts.map(s => `
        <tr>
            <td><span style="font-family: monospace; color: var(--sky-400);">${escapeHtml(s.script_id)}</span></td>
            <td style="font-size: 11px; color: var(--text-secondary); max-width: 300px; overflow: hidden; text-overflow: ellipsis;">${escapeHtml(s.script_path || s.path || '')}</td>
            <td style="font-size: 11px;">${escapeHtml(s.description || '-')}</td>
            <td style="font-size: 11px;">${s.timeout || 300}s</td>
        </tr>
    `).join('');
}

function renderApproverDropdown() {
    const select = document.getElementById('wfApproverEmail');
    if (approvers.length === 0) {
        const parent = select.parentElement;
        const input = document.createElement('input');
        input.type = 'email';
        input.className = 'form-input';
        input.id = 'wfApproverEmail';
        input.placeholder = 'approver@company.com';
        input.required = true;
        select.replaceWith(input);
        return;
    }
    select.innerHTML = '<option value="">-- Select approver --</option>' + 
        approvers.map(a => {
            const display = a.full_name ? `${a.full_name} (${a.username})` : a.username;
            const email = a.email || '';
            return `<option value="${escapeHtml(email)}" title="${escapeHtml(a.role || 'approver')}">${escapeHtml(display)}${email ? ' - ' + escapeHtml(email) : ''}</option>`;
        }).join('');
}

// ==========================================================================
// Workflow Actions
// ==========================================================================

function selectWorkflow(id) { 
    selectedWorkflow = id; 
    renderWorkflows(); 
    updateLogsPanel(); 
}

async function createWorkflow() {
    const scriptId = document.getElementById('wfScriptId').value;
    const requestor = document.getElementById('wfRequestor').value.trim();
    const requestorEmail = document.getElementById('wfRequestorEmail').value.trim();
    const approverEmail = document.getElementById('wfApproverEmail').value.trim();
    const reason = document.getElementById('wfReason').value.trim();
    
    if (!scriptId) { addLog('Please select a script', 'error'); return; }
    if (!requestor || !reason) { addLog('Please fill in all workflow fields', 'error'); return; }
    if (!approverEmail) { addLog('Please enter approver email for notifications', 'error'); return; }
    if (selectedAgents.length === 0) { addLog('Please select at least one target agent', 'error'); return; }
    
    try {
        await apiCall('/workflows', { 
            method: 'POST', 
            body: JSON.stringify({ 
                script_id: scriptId, 
                targets: selectedAgents, 
                requestor, 
                requestor_email: requestorEmail,
                notify_email: approverEmail,
                reason, 
                required_approval_levels: 1, 
                ttl_minutes: 60 
            }) 
        });
        addLog('Workflow created - approval notification sent to ' + approverEmail, 'success');
        document.getElementById('wfScriptId').selectedIndex = 0; 
        document.getElementById('wfReason').value = '';
        document.getElementById('wfApproverEmail').value = '';
        selectedAgents = []; 
        document.getElementById('selectedCount').textContent = '0'; 
        loadData();
    } catch (err) { 
        addLog(`Failed to create workflow: ${err.message}`, 'error'); 
    }
}

async function approveWorkflow(id) {
    try { 
        await apiCall(`/workflows/${id}/approve`, { 
            method: 'POST', 
            body: JSON.stringify({ approver: currentUser?.username || 'admin', note: 'Approved from dashboard' }) 
        }); 
        addLog(`Workflow ${id} approved`, 'success'); 
        loadData(); 
    } catch (err) { 
        addLog(`Failed to approve: ${err.message}`, 'error'); 
    }
}

function denyWorkflow(id) {
    pendingDenyWorkflowId = id;
    document.getElementById('denyWorkflowId').textContent = id;
    document.getElementById('denyReason').value = '';
    document.getElementById('denyModal').classList.add('active');
    document.getElementById('denyReason').focus();
}

function closeDenyModal() {
    document.getElementById('denyModal').classList.remove('active');
    pendingDenyWorkflowId = null;
}

async function confirmDeny() {
    if (!pendingDenyWorkflowId) return;
    const reason = document.getElementById('denyReason').value.trim() || 'Denied from dashboard';
    try { 
        await apiCall(`/workflows/${pendingDenyWorkflowId}/deny`, { 
            method: 'POST', 
            body: JSON.stringify({ 
                denier: currentUser?.username || 'admin', 
                reason: reason 
            }) 
        }); 
        addLog(`Workflow ${pendingDenyWorkflowId} denied: ${reason}`, 'warning'); 
        closeDenyModal();
        loadData(); 
    } catch (err) { 
        addLog(`Failed to deny: ${err.message}`, 'error'); 
        closeDenyModal();
    }
}

async function executeWorkflow(id) {
    try {
        addLog(`Executing workflow ${id}...`, 'info');
        const result = await apiCall(`/workflows/${id}/execute`, { method: 'POST' });
        
        const successCount = result?.script_result?.success_count ?? result?.success_count ?? 0;
        const failureCount = result?.script_result?.failure_count ?? result?.failure_count ?? 0;
        
        if (failureCount === 0) {
            addLog(`✅ Workflow ${id} executed successfully on ${successCount} agent(s)`, 'success');
        } else {
            addLog(`⚠️ Workflow ${id} completed with ${failureCount} failure(s)`, 'error');
        }
        
        const stdout = result?.script_result?.results?.[0]?.result?.stdout ?? result?.script_result?.results?.[0]?.stdout ?? '';
        const files = extractAllLogfiles(stdout);
        if (files.html || files.text) { 
            logfiles[id] = files;
            if (files.html) addLog(`HTML output: ${files.html}`, 'success');
            if (files.text) addLog(`Text log: ${files.text}`, 'success'); 
            selectedWorkflow = id; 
            logsExpanded = true; 
            updateLogsPanel(); 
        }
        
        await loadData();
        
    } catch (err) { 
        addLog(`❌ Execution failed: ${err.message}`, 'error'); 
        await loadData();
    }
}

// ==========================================================================
// Agent & Script Registration
// ==========================================================================

function toggleAgentSelection(name, checked) { 
    if (checked) { 
        if (!selectedAgents.includes(name)) selectedAgents.push(name); 
    } else { 
        selectedAgents = selectedAgents.filter(a => a !== name); 
    } 
    document.getElementById('selectedCount').textContent = selectedAgents.length; 
}

async function registerAgent() {
    const name = document.getElementById('agentName').value.trim();
    const host = document.getElementById('agentHost').value.trim();
    const portStr = document.getElementById('agentPort').value.trim();
    
    if (!name || !host || !portStr) { addLog('Please fill in all agent fields', 'error'); return; }
    const port = parseInt(portStr, 10); 
    if (isNaN(port) || port < 1 || port > 65535) { addLog('Port must be between 1-65535', 'error'); return; }
    
    try { 
        await apiCall('/agents/register', { method: 'POST', body: JSON.stringify({ agent_name: name, host, port }) }); 
        addLog(`Agent ${name} registered`, 'success'); 
        document.getElementById('agentName').value = ''; 
        document.getElementById('agentHost').value = ''; 
        document.getElementById('agentPort').value = '8001'; 
        loadData(); 
    } catch (err) { 
        addLog(`Failed to register agent: ${err.message}`, 'error'); 
    }
}

async function registerScript() {
    const scriptId = document.getElementById('scriptId').value.trim();
    const scriptPath = document.getElementById('scriptPath').value.trim();
    const description = document.getElementById('scriptDescription').value.trim();
    const timeout = parseInt(document.getElementById('scriptTimeout').value) || 300;

    if (!scriptId) { addLog('Please enter a Script ID', 'error'); return; }
    if (!scriptPath) { addLog('Please enter a Script Path', 'error'); return; }
    if (!/^[a-zA-Z0-9_-]+$/.test(scriptId)) { addLog('Script ID must contain only letters, numbers, hyphens and underscores', 'error'); return; }

    try {
        await apiCall('/scripts/register', {
            method: 'POST',
            body: JSON.stringify({
                script_id: scriptId,
                script_path: scriptPath,
                description: description,
                timeout: timeout
            })
        });
        addLog(`Script '${scriptId}' registered successfully`, 'success');
        document.getElementById('scriptId').value = '';
        document.getElementById('scriptPath').value = '';
        document.getElementById('scriptDescription').value = '';
        document.getElementById('scriptTimeout').value = '300';
        loadScripts();
    } catch (err) {
        addLog(`Failed to register script: ${err.message}`, 'error');
    }
}

// ==========================================================================
// Logs Panel
// ==========================================================================

function extractLogfile(stdout) { 
    if (!stdout) return null; 
    const clean = stdout.replace(/\u001b\[[0-9;]*m/g, '').replace(/\/\/+/g, '/'); 
    const htmlMatch = clean.match(/(\/[A-Za-z0-9_\-\/\.]+\.html)/);
    if (htmlMatch) return htmlMatch[1];
    const logMatch = clean.match(/(\/[A-Za-z0-9_\-\/\.]+\.log)/); 
    return logMatch ? logMatch[1] : null; 
}

function extractAllLogfiles(stdout) {
    if (!stdout) return { html: null, text: null };
    const clean = stdout.replace(/\u001b\[[0-9;]*m/g, '').replace(/\/\/+/g, '/');
    const htmlMatch = clean.match(/(\/[A-Za-z0-9_\-\/\.]+\.html)/);
    const logMatch = clean.match(/(\/[A-Za-z0-9_\-\/\.]+\.log)/);
    return { html: htmlMatch ? htmlMatch[1] : null, text: logMatch ? logMatch[1] : null };
}

function updateLogsPanel() {
    const panel = document.getElementById('logsPanel');
    const files = selectedWorkflow ? logfiles[selectedWorkflow] : null;
    
    const htmlFile = typeof files === 'object' ? files?.html : null;
    const textFile = typeof files === 'object' ? files?.text : (typeof files === 'string' ? files : null);
    
    if (!selectedWorkflow || (!htmlFile && !textFile)) { 
        panel.classList.add('hidden'); 
        return; 
    }
    
    panel.classList.remove('hidden');
    document.getElementById('logsWorkflowId').textContent = selectedWorkflow;
    document.getElementById('logsPath').textContent = htmlFile || textFile;
    document.getElementById('logsIcon').textContent = logsExpanded ? '▼' : '►';
    document.getElementById('logsContent').classList.toggle('hidden', !logsExpanded);
    
    document.getElementById('btnViewHtml').style.display = htmlFile ? 'inline-block' : 'none';
    document.getElementById('btnViewText').style.display = textFile ? 'inline-block' : 'none';
}

function toggleLogs() { logsExpanded = !logsExpanded; updateLogsPanel(); }

function viewHtmlLog() { 
    const files = logfiles[selectedWorkflow]; 
    const path = typeof files === 'object' ? files?.html : null;
    if (path) window.open(`${API_BASE}/logs/file?path=${encodeURIComponent(path)}`, '_blank'); 
}

function viewTextLog() { 
    const files = logfiles[selectedWorkflow]; 
    const path = typeof files === 'object' ? files?.text : (typeof files === 'string' ? files : null);
    if (path) window.open(`${API_BASE}/logs/file?path=${encodeURIComponent(path)}`, '_blank'); 
}

function viewLiveLogs() { 
    const files = logfiles[selectedWorkflow]; 
    const path = typeof files === 'object' ? (files?.html || files?.text) : files;
    if (path) window.open(`${API_BASE}/logs/tail?path=${encodeURIComponent(path)}`, '_blank'); 
}

function openWorkflowLog(workflowId) {
    const files = logfiles[workflowId];
    const path = typeof files === 'object' ? (files?.html || files?.text) : files;
    if (path) window.open(`${API_BASE}/logs/file?path=${encodeURIComponent(path)}`, '_blank');
}

// ==========================================================================
// Activity Log
// ==========================================================================

function addLog(message, type = 'info') { 
    const ts = new Date().toLocaleTimeString(); 
    logs.push({ message, type, timestamp: ts }); 
    if (logs.length > 50) logs.shift(); 
    const ta = document.getElementById('activityLog'); 
    ta.value = logs.map(l => `${l.timestamp} [${l.type.toUpperCase()}] ${l.message}`).join('\n'); 
    ta.scrollTop = ta.scrollHeight; 
}

function clearLogs() { 
    logs = []; 
    document.getElementById('activityLog').value = ''; 
}

// ==========================================================================
// Utilities
// ==========================================================================

function escapeHtml(t) { 
    if (!t) return ''; 
    const d = document.createElement('div'); 
    d.textContent = t; 
    return d.innerHTML; 
}

function formatDate(ds) { 
    if (!ds) return 'Never'; 
    const d = new Date(ds), n = new Date(), m = Math.floor((n - d) / 60000); 
    if (m < 1) return 'Just now'; 
    if (m < 60) return `${m}m ago`; 
    const h = Math.floor(m / 60); 
    if (h < 24) return `${h}h ago`; 
    return d.toLocaleDateString(); 
}

// ==========================================================================
// Modal Keyboard Support
// ==========================================================================

document.addEventListener('keydown', (e) => {
    const modal = document.getElementById('denyModal');
    if (!modal.classList.contains('active')) return;
    if (e.key === 'Escape') closeDenyModal();
    if (e.key === 'Enter' && e.ctrlKey) confirmDeny();
});

document.getElementById('denyModal').addEventListener('click', (e) => {
    if (e.target.id === 'denyModal') closeDenyModal();
});
