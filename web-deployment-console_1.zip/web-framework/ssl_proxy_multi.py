#!/usr/bin/env python3
"""
Enhanced SSL Proxy with Multi-Backend Support
==============================================

Features:
- Multiple backend routing based on URL path
- WebSocket support for real-time applications
- Smart Card (client certificate) authentication as primary
- Windows Native Auth (NTLM/Kerberos) as automatic fallback
- Health checks for backends
- Connection pooling
- Request/Response logging

Usage:
    python ssl_proxy_multi.py [--config config.yaml]
"""

import asyncio
import base64
import hashlib
import hmac
import json
import logging
import os
import re
import signal
import ssl
import struct
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from urllib.parse import urlparse, parse_qs
import socket

# Optional YAML config support
try:
    import yaml
    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False

# ============================================================================
# Configuration
# ============================================================================

@dataclass
class BackendConfig:
    """Configuration for a single backend service"""
    name: str
    host: str
    port: int
    path_prefix: str = "/"
    strip_prefix: bool = True
    websocket: bool = False
    health_check_path: str = "/health"
    health_check_interval: int = 30
    timeout: int = 300
    max_connections: int = 100
    auth_required: bool = True
    allowed_roles: List[str] = field(default_factory=list)
    
    @property
    def base_url(self) -> str:
        return f"http://{self.host}:{self.port}"


@dataclass  
class ProxyConfig:
    """Main proxy configuration"""
    # Listening
    listen_host: str = "0.0.0.0"
    listen_port: int = 8443
    
    # SSL/TLS
    ssl_cert: str = "/etc/ssl/proxy/server.crt"
    ssl_key: str = "/etc/ssl/proxy/server.key"
    ssl_ca: str = "/etc/ssl/proxy/ca.crt"
    ssl_verify_client: bool = True
    
    # Authentication
    ntlm_fallback: bool = True
    ntlm_domain: str = ""
    session_timeout: int = 3600
    
    # Logging
    log_level: str = "INFO"
    log_file: str = "./proxy.log"
    access_log: str = "./access.log"
    
    # Backends
    backends: Dict[str, BackendConfig] = field(default_factory=dict)
    
    # Default backend (when no path matches)
    default_backend: str = ""


# Default configuration with your backends
DEFAULT_CONFIG = ProxyConfig(
    listen_port=8443,
    backends={
        # Your existing orchestration dashboard
        "orchestration": BackendConfig(
            name="Orchestration Dashboard",
            host="localhost",
            port=8000,
            path_prefix="/",
            strip_prefix=False,
            websocket=True,
            auth_required=True,
        ),
        
        # New deployment console
        "deploy-console": BackendConfig(
            name="Deployment Console",
            host="localhost",
            port=8080,
            path_prefix="/deploy",
            strip_prefix=True,
            websocket=True,
            auth_required=True,
        ),
        
        # Example: API backend
        "api": BackendConfig(
            name="API Backend",
            host="localhost",
            port=8001,
            path_prefix="/api/v2",
            strip_prefix=False,
            websocket=False,
            auth_required=True,
        ),
        
        # Example: Static files (no auth)
        "static": BackendConfig(
            name="Static Files",
            host="localhost",
            port=8002,
            path_prefix="/static",
            strip_prefix=True,
            websocket=False,
            auth_required=False,
        ),
    },
    default_backend="orchestration",
)


# ============================================================================
# Logging Setup
# ============================================================================

def setup_logging(config: ProxyConfig) -> logging.Logger:
    """Configure logging"""
    logger = logging.getLogger("ssl_proxy")
    logger.setLevel(getattr(logging, config.log_level.upper()))
    
    # Console handler
    console = logging.StreamHandler()
    console.setFormatter(logging.Formatter(
        '%(asctime)s [%(levelname)s] %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    ))
    logger.addHandler(console)
    
    # File handler
    if config.log_file:
        file_handler = logging.FileHandler(config.log_file)
        file_handler.setFormatter(logging.Formatter(
            '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
        ))
        logger.addHandler(file_handler)
    
    return logger


# ============================================================================
# Authentication Handlers
# ============================================================================

class AuthenticationManager:
    """Handles Smart Card and NTLM authentication"""
    
    def __init__(self, config: ProxyConfig, logger: logging.Logger):
        self.config = config
        self.logger = logger
        self.sessions: Dict[str, dict] = {}
        
    def extract_client_cert_info(self, ssl_object) -> Optional[dict]:
        """Extract user information from client certificate"""
        try:
            cert = ssl_object.getpeercert()
            if not cert:
                return None
            
            # Extract subject info
            subject = dict(x[0] for x in cert.get('subject', []))
            
            user_info = {
                'auth_method': 'smartcard',
                'cn': subject.get('commonName', ''),
                'email': subject.get('emailAddress', ''),
                'org': subject.get('organizationName', ''),
                'ou': subject.get('organizationalUnitName', ''),
                'serial': cert.get('serialNumber', ''),
                'not_after': cert.get('notAfter', ''),
                'authenticated_at': datetime.now().isoformat(),
            }
            
            # Parse CN for username (adjust pattern for your cert format)
            cn = user_info['cn']
            # Example: "CN=john.doe@example.com" or "CN=DOMAIN\\username"
            if '\\' in cn:
                user_info['username'] = cn.split('\\')[-1]
                user_info['domain'] = cn.split('\\')[0]
            elif '@' in cn:
                user_info['username'] = cn.split('@')[0]
                user_info['domain'] = cn.split('@')[1].split('.')[0].upper()
            else:
                user_info['username'] = cn
                
            return user_info
            
        except Exception as e:
            self.logger.error(f"Error extracting cert info: {e}")
            return None
    
    def create_ntlm_challenge(self) -> bytes:
        """Create NTLM Type 2 challenge message"""
        # Simplified NTLM challenge - in production use pyspnego or similar
        challenge = os.urandom(8)
        
        # NTLM Type 2 message structure (simplified)
        signature = b'NTLMSSP\x00'
        msg_type = struct.pack('<I', 2)  # Type 2
        
        target_name = self.config.ntlm_domain.encode('utf-16-le')
        target_len = struct.pack('<H', len(target_name))
        target_offset = struct.pack('<I', 56)
        
        flags = struct.pack('<I', 0xe2898235)  # Negotiate flags
        
        challenge_bytes = challenge
        reserved = b'\x00' * 8
        
        message = (signature + msg_type + target_len + target_len + 
                  target_offset + flags + challenge_bytes + reserved)
        
        # Store challenge for verification
        challenge_id = base64.b64encode(challenge).decode()
        self.sessions[challenge_id] = {
            'challenge': challenge,
            'created': time.time()
        }
        
        return base64.b64encode(message)
    
    def verify_ntlm_response(self, auth_header: str) -> Optional[dict]:
        """Verify NTLM Type 3 authentication response"""
        try:
            # Parse the NTLM message
            if not auth_header.startswith('NTLM '):
                return None
                
            ntlm_data = base64.b64decode(auth_header[5:])
            
            # Check signature
            if not ntlm_data.startswith(b'NTLMSSP\x00'):
                return None
            
            msg_type = struct.unpack('<I', ntlm_data[8:12])[0]
            
            if msg_type == 1:
                # Type 1 - return None to trigger challenge
                return None
            elif msg_type == 3:
                # Type 3 - extract username
                # This is simplified - real implementation needs proper parsing
                
                # Extract domain and username from Type 3 message
                domain_len = struct.unpack('<H', ntlm_data[28:30])[0]
                domain_offset = struct.unpack('<I', ntlm_data[32:36])[0]
                user_len = struct.unpack('<H', ntlm_data[36:38])[0]
                user_offset = struct.unpack('<I', ntlm_data[40:44])[0]
                
                domain = ntlm_data[domain_offset:domain_offset+domain_len].decode('utf-16-le')
                username = ntlm_data[user_offset:user_offset+user_len].decode('utf-16-le')
                
                # In production, verify against AD/LDAP here
                
                return {
                    'auth_method': 'ntlm',
                    'username': username,
                    'domain': domain,
                    'authenticated_at': datetime.now().isoformat(),
                }
                
        except Exception as e:
            self.logger.error(f"NTLM verification error: {e}")
            
        return None
    
    def create_session(self, user_info: dict) -> str:
        """Create authenticated session"""
        session_id = base64.b64encode(os.urandom(32)).decode()
        self.sessions[session_id] = {
            **user_info,
            'created': time.time(),
            'last_access': time.time(),
        }
        return session_id
    
    def validate_session(self, session_id: str) -> Optional[dict]:
        """Validate existing session"""
        session = self.sessions.get(session_id)
        if not session:
            return None
            
        # Check timeout
        if time.time() - session.get('created', 0) > self.config.session_timeout:
            del self.sessions[session_id]
            return None
            
        # Update last access
        session['last_access'] = time.time()
        return session
    
    def cleanup_sessions(self):
        """Remove expired sessions"""
        now = time.time()
        expired = [
            sid for sid, session in self.sessions.items()
            if now - session.get('created', 0) > self.config.session_timeout
        ]
        for sid in expired:
            del self.sessions[sid]


# ============================================================================
# Backend Router
# ============================================================================

class BackendRouter:
    """Routes requests to appropriate backend based on path"""
    
    def __init__(self, config: ProxyConfig, logger: logging.Logger):
        self.config = config
        self.logger = logger
        self.backend_health: Dict[str, bool] = {}
        
        # Sort backends by path prefix length (longest first for matching)
        self.sorted_backends = sorted(
            config.backends.items(),
            key=lambda x: len(x[1].path_prefix),
            reverse=True
        )
    
    def get_backend(self, path: str) -> Tuple[Optional[str], Optional[BackendConfig]]:
        """Find the appropriate backend for a request path"""
        for backend_id, backend in self.sorted_backends:
            if path.startswith(backend.path_prefix):
                return backend_id, backend
        
        # Return default backend if configured
        if self.config.default_backend:
            return self.config.default_backend, self.config.backends.get(self.config.default_backend)
            
        return None, None
    
    def transform_path(self, path: str, backend: BackendConfig) -> str:
        """Transform request path for backend"""
        if backend.strip_prefix and path.startswith(backend.path_prefix):
            new_path = path[len(backend.path_prefix):]
            if not new_path.startswith('/'):
                new_path = '/' + new_path
            return new_path
        return path
    
    async def check_backend_health(self, backend_id: str, backend: BackendConfig) -> bool:
        """Check if backend is healthy"""
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(backend.host, backend.port),
                timeout=5
            )
            
            # Send health check request
            request = (
                f"GET {backend.health_check_path} HTTP/1.1\r\n"
                f"Host: {backend.host}:{backend.port}\r\n"
                f"Connection: close\r\n\r\n"
            )
            writer.write(request.encode())
            await writer.drain()
            
            # Read response
            response = await asyncio.wait_for(reader.read(1024), timeout=5)
            writer.close()
            await writer.wait_closed()
            
            # Check for successful response
            is_healthy = b'200' in response[:20] or b'404' in response[:20]
            self.backend_health[backend_id] = is_healthy
            return is_healthy
            
        except Exception as e:
            self.logger.warning(f"Health check failed for {backend_id}: {e}")
            self.backend_health[backend_id] = False
            return False
    
    async def run_health_checks(self):
        """Periodically check all backends"""
        while True:
            for backend_id, backend in self.config.backends.items():
                await self.check_backend_health(backend_id, backend)
            await asyncio.sleep(30)  # Check every 30 seconds


# ============================================================================
# WebSocket Handler
# ============================================================================

class WebSocketHandler:
    """Handles WebSocket upgrade and proxying"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
    
    def is_websocket_request(self, headers: dict) -> bool:
        """Check if request is a WebSocket upgrade"""
        upgrade = headers.get('upgrade', '').lower()
        connection = headers.get('connection', '').lower()
        return 'websocket' in upgrade and 'upgrade' in connection
    
    async def create_websocket_handshake(self, key: str) -> str:
        """Create WebSocket accept key"""
        GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
        accept = base64.b64encode(
            hashlib.sha1((key + GUID).encode()).digest()
        ).decode()
        return accept
    
    async def proxy_websocket(
        self, 
        client_reader: asyncio.StreamReader,
        client_writer: asyncio.StreamWriter,
        backend_reader: asyncio.StreamReader,
        backend_writer: asyncio.StreamWriter
    ):
        """Bidirectional WebSocket proxying"""
        
        async def forward(reader, writer, direction):
            try:
                while True:
                    data = await reader.read(65536)
                    if not data:
                        break
                    writer.write(data)
                    await writer.drain()
            except asyncio.CancelledError:
                pass
            except Exception as e:
                self.logger.debug(f"WebSocket {direction} closed: {e}")
        
        # Create bidirectional forwarding tasks
        client_to_backend = asyncio.create_task(
            forward(client_reader, backend_writer, "client->backend")
        )
        backend_to_client = asyncio.create_task(
            forward(backend_reader, client_writer, "backend->client")
        )
        
        # Wait for either direction to complete
        done, pending = await asyncio.wait(
            [client_to_backend, backend_to_client],
            return_when=asyncio.FIRST_COMPLETED
        )
        
        # Cancel the other task
        for task in pending:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass


# ============================================================================
# HTTP Parser
# ============================================================================

class HTTPParser:
    """Simple HTTP request/response parser"""
    
    @staticmethod
    def parse_request(data: bytes) -> Tuple[str, str, str, dict, bytes]:
        """Parse HTTP request into method, path, version, headers, body"""
        try:
            # Split headers and body
            if b'\r\n\r\n' in data:
                header_data, body = data.split(b'\r\n\r\n', 1)
            else:
                header_data, body = data, b''
            
            lines = header_data.decode('utf-8', errors='replace').split('\r\n')
            
            # Parse request line
            request_line = lines[0].split(' ')
            method = request_line[0]
            path = request_line[1] if len(request_line) > 1 else '/'
            version = request_line[2] if len(request_line) > 2 else 'HTTP/1.1'
            
            # Parse headers
            headers = {}
            for line in lines[1:]:
                if ':' in line:
                    key, value = line.split(':', 1)
                    headers[key.strip().lower()] = value.strip()
            
            return method, path, version, headers, body
            
        except Exception:
            return 'GET', '/', 'HTTP/1.1', {}, b''
    
    @staticmethod
    def build_request(
        method: str, 
        path: str, 
        headers: dict, 
        body: bytes = b'',
        version: str = 'HTTP/1.1'
    ) -> bytes:
        """Build HTTP request from components"""
        lines = [f"{method} {path} {version}"]
        for key, value in headers.items():
            lines.append(f"{key}: {value}")
        
        header_str = '\r\n'.join(lines) + '\r\n\r\n'
        return header_str.encode() + body
    
    @staticmethod
    def build_response(
        status: int,
        reason: str,
        headers: dict,
        body: bytes = b''
    ) -> bytes:
        """Build HTTP response"""
        lines = [f"HTTP/1.1 {status} {reason}"]
        for key, value in headers.items():
            lines.append(f"{key}: {value}")
        
        header_str = '\r\n'.join(lines) + '\r\n\r\n'
        return header_str.encode() + body


# ============================================================================
# Main Proxy Server
# ============================================================================

class MultiBackendProxy:
    """Main proxy server with multi-backend support"""
    
    def __init__(self, config: ProxyConfig):
        self.config = config
        self.logger = setup_logging(config)
        self.auth_manager = AuthenticationManager(config, self.logger)
        self.router = BackendRouter(config, self.logger)
        self.ws_handler = WebSocketHandler(self.logger)
        self.running = False
        
        # Access log
        self.access_log = None
        if config.access_log:
            self.access_log = open(config.access_log, 'a')
    
    def log_access(
        self, 
        client_addr: str, 
        method: str, 
        path: str, 
        status: int,
        backend: str,
        user: str,
        duration: float
    ):
        """Log access request"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        log_line = f'{timestamp} {client_addr} "{method} {path}" {status} {backend} {user} {duration:.3f}s\n'
        
        if self.access_log:
            self.access_log.write(log_line)
            self.access_log.flush()
    
    async def handle_client(
        self, 
        reader: asyncio.StreamReader, 
        writer: asyncio.StreamWriter
    ):
        """Handle incoming client connection"""
        start_time = time.time()
        client_addr = writer.get_extra_info('peername')
        ssl_object = writer.get_extra_info('ssl_object')
        
        user_info = None
        backend_id = None
        method, path = 'UNKNOWN', '/'
        status = 500
        
        try:
            # Read request
            request_data = await asyncio.wait_for(
                reader.read(65536),
                timeout=30
            )
            
            if not request_data:
                return
            
            # Parse request
            method, path, version, headers, body = HTTPParser.parse_request(request_data)
            
            # Find backend
            backend_id, backend = self.router.get_backend(path)
            
            if not backend:
                # No matching backend
                response = HTTPParser.build_response(
                    404, 'Not Found',
                    {'Content-Type': 'text/plain'},
                    b'No backend configured for this path'
                )
                writer.write(response)
                await writer.drain()
                status = 404
                return
            
            # Authentication
            if backend.auth_required:
                # Try Smart Card first
                user_info = self.auth_manager.extract_client_cert_info(ssl_object)
                
                if not user_info and self.config.ntlm_fallback:
                    # Check for existing session
                    session_cookie = self._extract_session_cookie(headers)
                    if session_cookie:
                        user_info = self.auth_manager.validate_session(session_cookie)
                    
                    if not user_info:
                        # Try NTLM
                        auth_header = headers.get('authorization', '')
                        
                        if auth_header.startswith('NTLM '):
                            user_info = self.auth_manager.verify_ntlm_response(auth_header)
                            
                            if not user_info:
                                # Send NTLM challenge
                                challenge = self.auth_manager.create_ntlm_challenge()
                                response = HTTPParser.build_response(
                                    401, 'Unauthorized',
                                    {
                                        'WWW-Authenticate': f'NTLM {challenge.decode()}',
                                        'Connection': 'keep-alive',
                                    }
                                )
                                writer.write(response)
                                await writer.drain()
                                status = 401
                                return
                        else:
                            # Request NTLM authentication
                            response = HTTPParser.build_response(
                                401, 'Unauthorized',
                                {
                                    'WWW-Authenticate': 'NTLM',
                                    'Connection': 'keep-alive',
                                }
                            )
                            writer.write(response)
                            await writer.drain()
                            status = 401
                            return
                
                if not user_info:
                    response = HTTPParser.build_response(
                        401, 'Unauthorized',
                        {'Content-Type': 'text/plain'},
                        b'Authentication required'
                    )
                    writer.write(response)
                    await writer.drain()
                    status = 401
                    return
            
            # Transform path for backend
            backend_path = self.router.transform_path(path, backend)
            
            # Connect to backend
            try:
                backend_reader, backend_writer = await asyncio.wait_for(
                    asyncio.open_connection(backend.host, backend.port),
                    timeout=10
                )
            except Exception as e:
                self.logger.error(f"Backend connection failed: {e}")
                response = HTTPParser.build_response(
                    502, 'Bad Gateway',
                    {'Content-Type': 'text/plain'},
                    f'Backend unavailable: {backend.name}'.encode()
                )
                writer.write(response)
                await writer.drain()
                status = 502
                return
            
            try:
                # Check for WebSocket upgrade
                if backend.websocket and self.ws_handler.is_websocket_request(headers):
                    await self._handle_websocket(
                        reader, writer, 
                        backend_reader, backend_writer,
                        method, backend_path, headers, body,
                        backend, user_info
                    )
                    status = 101
                else:
                    # Regular HTTP request
                    status = await self._proxy_http(
                        reader, writer,
                        backend_reader, backend_writer,
                        method, backend_path, headers, body,
                        backend, user_info
                    )
                    
            finally:
                backend_writer.close()
                await backend_writer.wait_closed()
                
        except asyncio.TimeoutError:
            self.logger.warning(f"Request timeout from {client_addr}")
            status = 408
        except Exception as e:
            self.logger.error(f"Error handling request: {e}")
            status = 500
        finally:
            # Log access
            duration = time.time() - start_time
            username = user_info.get('username', '-') if user_info else '-'
            self.log_access(
                str(client_addr), method, path, status,
                backend_id or '-', username, duration
            )
            
            writer.close()
            await writer.wait_closed()
    
    def _extract_session_cookie(self, headers: dict) -> Optional[str]:
        """Extract session ID from cookies"""
        cookie_header = headers.get('cookie', '')
        for cookie in cookie_header.split(';'):
            cookie = cookie.strip()
            if cookie.startswith('proxy_session='):
                return cookie.split('=', 1)[1]
        return None
    
    async def _handle_websocket(
        self,
        client_reader, client_writer,
        backend_reader, backend_writer,
        method, path, headers, body,
        backend: BackendConfig,
        user_info: Optional[dict]
    ):
        """Handle WebSocket upgrade and proxying"""
        # Add user info to headers
        backend_headers = dict(headers)
        backend_headers['host'] = f"{backend.host}:{backend.port}"
        
        if user_info:
            backend_headers['x-authenticated-user'] = user_info.get('username', '')
            backend_headers['x-auth-method'] = user_info.get('auth_method', '')
        
        # Forward upgrade request to backend
        request = HTTPParser.build_request(method, path, backend_headers, body)
        backend_writer.write(request)
        await backend_writer.drain()
        
        # Read backend response
        response_data = await backend_reader.read(4096)
        
        # Forward response to client
        client_writer.write(response_data)
        await client_writer.drain()
        
        # Check if upgrade was successful
        if b'101' in response_data[:20]:
            # Start WebSocket proxying
            await self.ws_handler.proxy_websocket(
                client_reader, client_writer,
                backend_reader, backend_writer
            )
    
    async def _proxy_http(
        self,
        client_reader, client_writer,
        backend_reader, backend_writer,
        method, path, headers, body,
        backend: BackendConfig,
        user_info: Optional[dict]
    ) -> int:
        """Proxy regular HTTP request"""
        # Prepare backend headers
        backend_headers = dict(headers)
        backend_headers['host'] = f"{backend.host}:{backend.port}"
        
        # Add authentication info
        if user_info:
            backend_headers['x-authenticated-user'] = user_info.get('username', '')
            backend_headers['x-auth-method'] = user_info.get('auth_method', '')
            backend_headers['x-user-domain'] = user_info.get('domain', '')
            backend_headers['x-user-cn'] = user_info.get('cn', '')
        
        # Remove hop-by-hop headers
        for hop_header in ['connection', 'keep-alive', 'proxy-authenticate', 
                          'proxy-authorization', 'te', 'trailers', 
                          'transfer-encoding', 'upgrade']:
            backend_headers.pop(hop_header, None)
        
        # Forward request to backend
        request = HTTPParser.build_request(method, path, backend_headers, body)
        backend_writer.write(request)
        await backend_writer.drain()
        
        # Read and forward response
        status = 200
        while True:
            chunk = await asyncio.wait_for(
                backend_reader.read(65536),
                timeout=backend.timeout
            )
            
            if not chunk:
                break
            
            # Parse status from first chunk
            if b'HTTP/' in chunk[:10]:
                try:
                    status_line = chunk.split(b'\r\n')[0].decode()
                    status = int(status_line.split()[1])
                except:
                    pass
            
            client_writer.write(chunk)
            await client_writer.drain()
        
        return status
    
    def _create_ssl_context(self) -> ssl.SSLContext:
        """Create SSL context with client cert support"""
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        
        # Load server certificate
        context.load_cert_chain(
            certfile=self.config.ssl_cert,
            keyfile=self.config.ssl_key
        )
        
        # Configure client certificate verification
        if self.config.ssl_verify_client:
            context.verify_mode = ssl.CERT_OPTIONAL  # Optional for NTLM fallback
            if os.path.exists(self.config.ssl_ca):
                context.load_verify_locations(self.config.ssl_ca)
        
        # Security settings
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        context.set_ciphers('ECDHE+AESGCM:DHE+AESGCM:ECDHE+CHACHA20')
        
        return context
    
    async def start(self):
        """Start the proxy server"""
        ssl_context = self._create_ssl_context()
        
        server = await asyncio.start_server(
            self.handle_client,
            self.config.listen_host,
            self.config.listen_port,
            ssl=ssl_context
        )
        
        self.running = True
        
        # Start health check task
        health_task = asyncio.create_task(self.router.run_health_checks())
        
        # Print startup info
        self.logger.info("=" * 60)
        self.logger.info("Multi-Backend SSL Proxy Started")
        self.logger.info("=" * 60)
        self.logger.info(f"Listening on: {self.config.listen_host}:{self.config.listen_port}")
        self.logger.info(f"SSL Certificate: {self.config.ssl_cert}")
        self.logger.info(f"Client Cert Verification: {self.config.ssl_verify_client}")
        self.logger.info(f"NTLM Fallback: {self.config.ntlm_fallback}")
        self.logger.info("-" * 60)
        self.logger.info("Configured Backends:")
        for backend_id, backend in self.config.backends.items():
            self.logger.info(
                f"  [{backend_id}] {backend.path_prefix} -> "
                f"{backend.host}:{backend.port} "
                f"({'WS' if backend.websocket else 'HTTP'}, "
                f"{'Auth' if backend.auth_required else 'NoAuth'})"
            )
        self.logger.info("=" * 60)
        
        try:
            async with server:
                await server.serve_forever()
        finally:
            health_task.cancel()
            if self.access_log:
                self.access_log.close()
    
    def stop(self):
        """Stop the proxy server"""
        self.running = False


# ============================================================================
# Configuration Loading
# ============================================================================

def load_config(config_path: Optional[str] = None) -> ProxyConfig:
    """Load configuration from file or use defaults"""
    
    if config_path and os.path.exists(config_path):
        if YAML_AVAILABLE and config_path.endswith(('.yaml', '.yml')):
            with open(config_path) as f:
                data = yaml.safe_load(f)
                
            config = ProxyConfig(
                listen_host=data.get('listen_host', '0.0.0.0'),
                listen_port=data.get('listen_port', 8443),
                ssl_cert=data.get('ssl_cert', '/etc/ssl/proxy/server.crt'),
                ssl_key=data.get('ssl_key', '/etc/ssl/proxy/server.key'),
                ssl_ca=data.get('ssl_ca', '/etc/ssl/proxy/ca.crt'),
                ssl_verify_client=data.get('ssl_verify_client', True),
                ntlm_fallback=data.get('ntlm_fallback', True),
                ntlm_domain=data.get('ntlm_domain', ''),
                session_timeout=data.get('session_timeout', 3600),
                log_level=data.get('log_level', 'INFO'),
                log_file=data.get('log_file', './proxy.log'),
                access_log=data.get('access_log', './access.log'),
                default_backend=data.get('default_backend', ''),
            )
            
            # Parse backends
            for backend_id, backend_data in data.get('backends', {}).items():
                config.backends[backend_id] = BackendConfig(
                    name=backend_data.get('name', backend_id),
                    host=backend_data.get('host', 'localhost'),
                    port=backend_data.get('port', 8000),
                    path_prefix=backend_data.get('path_prefix', '/'),
                    strip_prefix=backend_data.get('strip_prefix', True),
                    websocket=backend_data.get('websocket', False),
                    health_check_path=backend_data.get('health_check_path', '/health'),
                    timeout=backend_data.get('timeout', 300),
                    auth_required=backend_data.get('auth_required', True),
                )
            
            return config
    
    return DEFAULT_CONFIG


# ============================================================================
# Main Entry Point
# ============================================================================

def main():
    """Main entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Multi-Backend SSL Proxy')
    parser.add_argument('--config', '-c', help='Configuration file path')
    parser.add_argument('--port', '-p', type=int, help='Listen port')
    parser.add_argument('--host', '-H', help='Listen host')
    args = parser.parse_args()
    
    # Load configuration
    config = load_config(args.config)
    
    # Override with command line args
    if args.port:
        config.listen_port = args.port
    if args.host:
        config.listen_host = args.host
    
    # Create and start proxy
    proxy = MultiBackendProxy(config)
    
    # Handle signals
    def signal_handler(sig, frame):
        print("\nShutting down...")
        proxy.stop()
        sys.exit(0)
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Run
    asyncio.run(proxy.start())


if __name__ == '__main__':
    main()
