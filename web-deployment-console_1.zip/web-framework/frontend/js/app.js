/**
 * Oracle EBS Deployment Console
 * Vanilla JavaScript Application
 */

// ============================================================================
// Application State
// ============================================================================

const state = {
    registry: null,
    currentTier: null,
    currentMenu: null,
    currentScript: null,
    executionId: null,
    websocket: null,
    isExecuting: false,
    outputBuffer: [],
    pendingParams: null
};

// API Base URL
const API_BASE = window.location.origin;

// ============================================================================
// Initialization
// ============================================================================

document.addEventListener('DOMContentLoaded', async () => {
    await initialize();
});

async function initialize() {
    try {
        // Load script registry
        await loadRegistry();
        
        // Render dashboard
        renderDashboard();
        
        // Load system info
        await loadSystemInfo();
        
        // Setup keyboard shortcuts
        setupKeyboardShortcuts();
        
        showToast('success', 'Console ready');
    } catch (error) {
        console.error('Initialization failed:', error);
        showToast('error', 'Failed to initialize console');
    }
}

async function loadRegistry() {
    const response = await fetch(`${API_BASE}/api/registry`);
    if (!response.ok) throw new Error('Failed to load registry');
    state.registry = await response.json();
}

async function loadSystemInfo() {
    try {
        const response = await fetch(`${API_BASE}/api/health`);
        const data = await response.json();
        
        document.getElementById('hostInfo').textContent = 
            data.deployment_home?.split('/').pop() || 'Unknown';
        document.getElementById('userInfo').textContent = 
            data.active_executions > 0 ? `${data.active_executions} active` : 'Ready';
        
        // Determine environment from deployment home
        const env = data.deployment_home?.includes('prod') ? 'PROD' : 
                   data.deployment_home?.includes('dev') ? 'DEV' : 'UAT';
        document.getElementById('envBadge').textContent = env;
        
    } catch (error) {
        console.error('Failed to load system info:', error);
    }
}

// ============================================================================
// Rendering Functions
// ============================================================================

function renderDashboard() {
    // Render tier navigation
    const tierNav = document.getElementById('tierNav');
    tierNav.innerHTML = '';
    
    for (const [tierId, tier] of Object.entries(state.registry)) {
        const menuCount = Object.keys(tier.menus).length;
        let scriptCount = 0;
        for (const menu of Object.values(tier.menus)) {
            scriptCount += Object.keys(menu.scripts).length;
        }
        
        // Nav item
        const navItem = document.createElement('li');
        navItem.className = 'nav-item';
        navItem.innerHTML = `
            <span class="nav-icon">${tier.icon}</span>
            <span>${tier.name}</span>
        `;
        navItem.onclick = () => selectTier(tierId);
        tierNav.appendChild(navItem);
    }
    
    // Render dashboard cards
    const dashboardGrid = document.querySelector('.dashboard-grid');
    dashboardGrid.innerHTML = '';
    
    for (const [tierId, tier] of Object.entries(state.registry)) {
        const menuCount = Object.keys(tier.menus).length;
        let scriptCount = 0;
        for (const menu of Object.values(tier.menus)) {
            scriptCount += Object.keys(menu.scripts).length;
        }
        
        const card = document.createElement('div');
        card.className = 'tier-card';
        card.innerHTML = `
            <div class="tier-card-header">
                <span class="tier-icon">${tier.icon}</span>
                <div>
                    <div class="tier-card-title">${tier.name}</div>
                    <div class="tier-card-subtitle">Oracle EBS Operations</div>
                </div>
            </div>
            <div class="tier-stats">
                <div class="stat">
                    <div class="stat-value">${menuCount}</div>
                    <div class="stat-label">Categories</div>
                </div>
                <div class="stat">
                    <div class="stat-value">${scriptCount}</div>
                    <div class="stat-label">Scripts</div>
                </div>
                <div class="stat">
                    <div class="stat-value">0</div>
                    <div class="stat-label">Running</div>
                </div>
            </div>
        `;
        card.onclick = () => selectTier(tierId);
        dashboardGrid.appendChild(card);
    }
    
    showPanel('dashboardPanel');
    updateBreadcrumb(['Home']);
    document.getElementById('pageTitle').textContent = 'Dashboard';
}

function renderScriptPanel(tierId) {
    const tier = state.registry[tierId];
    if (!tier) return;
    
    state.currentTier = tierId;
    
    // Update title
    document.getElementById('scriptPanelTitle').textContent = tier.name;
    document.getElementById('pageTitle').textContent = tier.name;
    updateBreadcrumb(['Home', tier.name]);
    
    // Render menu tabs
    const menuTabs = document.getElementById('menuTabs');
    menuTabs.innerHTML = '';
    
    const menuEntries = Object.entries(tier.menus);
    menuEntries.forEach(([menuId, menu], index) => {
        const tab = document.createElement('div');
        tab.className = `menu-tab ${index === 0 ? 'active' : ''}`;
        tab.textContent = menu.name;
        tab.onclick = () => selectMenu(menuId);
        menuTabs.appendChild(tab);
    });
    
    // Select first menu by default
    if (menuEntries.length > 0) {
        selectMenu(menuEntries[0][0]);
    }
    
    showPanel('scriptPanel');
    
    // Update nav active state
    document.querySelectorAll('.nav-item').forEach((item, i) => {
        item.classList.toggle('active', 
            item.textContent.includes(tier.name.split(' ')[0]));
    });
}

function selectMenu(menuId) {
    const tier = state.registry[state.currentTier];
    const menu = tier.menus[menuId];
    if (!menu) return;
    
    state.currentMenu = menuId;
    
    // Update tab active state
    document.querySelectorAll('.menu-tab').forEach(tab => {
        tab.classList.toggle('active', tab.textContent === menu.name);
    });
    
    // Render scripts
    const scriptGrid = document.getElementById('scriptGrid');
    scriptGrid.innerHTML = '';
    
    for (const [scriptId, script] of Object.entries(menu.scripts)) {
        const card = document.createElement('div');
        card.className = `script-card ${script.dangerous ? 'dangerous' : ''}`;
        
        let badges = '';
        if (script.confirm) {
            badges += '<span class="script-badge confirm">Confirm</span>';
        }
        if (script.remote) {
            badges += '<span class="script-badge remote">Remote</span>';
        }
        
        card.innerHTML = `
            <div class="script-card-header">
                <span class="script-id">${scriptId}</span>
                <div>${badges}</div>
            </div>
            <div class="script-name">${script.name}</div>
            <div class="script-file">${script.script}</div>
        `;
        card.onclick = () => prepareExecution(scriptId, script);
        scriptGrid.appendChild(card);
    }
}

// ============================================================================
// Execution Flow
// ============================================================================

function prepareExecution(scriptId, script) {
    state.currentScript = { id: scriptId, ...script };
    
    // Check if parameters are needed
    if (script.params && script.params.length > 0) {
        showParamModal(script.params);
        return;
    }
    
    // Check if confirmation is needed
    if (script.confirm || script.dangerous) {
        showConfirmModal(scriptId, script);
        return;
    }
    
    // Execute directly
    startExecution({});
}

function showParamModal(params) {
    const paramInputs = document.getElementById('paramInputs');
    paramInputs.innerHTML = '';
    
    params.forEach(param => {
        const group = document.createElement('div');
        group.className = 'param-group';
        group.innerHTML = `
            <label class="param-label">${formatParamName(param)}</label>
            <input type="text" class="param-field" name="${param}" 
                   placeholder="Enter ${formatParamName(param).toLowerCase()}">
        `;
        paramInputs.appendChild(group);
    });
    
    state.pendingParams = params;
    document.getElementById('paramModal').classList.remove('hidden');
}

function closeParamModal() {
    document.getElementById('paramModal').classList.add('hidden');
    state.pendingParams = null;
}

function submitParams() {
    const params = {};
    state.pendingParams.forEach(param => {
        const input = document.querySelector(`input[name="${param}"]`);
        params[param] = input?.value || '';
    });
    
    closeParamModal();
    
    // Show confirmation if needed
    if (state.currentScript.confirm || state.currentScript.dangerous) {
        showConfirmModal(state.currentScript.id, state.currentScript, params);
    } else {
        startExecution(params);
    }
}

function showConfirmModal(scriptId, script, params = {}) {
    const modal = document.getElementById('confirmModal');
    const message = document.getElementById('confirmMessage');
    const details = document.getElementById('confirmDetails');
    
    if (script.dangerous) {
        message.innerHTML = `
            <strong style="color: var(--error);">⚠️ DANGER</strong><br>
            This is a destructive operation. Are you absolutely sure?
        `;
    } else {
        message.textContent = `Are you sure you want to execute this script?`;
    }
    
    let detailsHtml = `
        <div><strong>Script:</strong> ${script.name}</div>
        <div><strong>File:</strong> ${script.script}</div>
        <div><strong>Tier:</strong> ${state.currentTier}</div>
    `;
    
    if (Object.keys(params).length > 0) {
        detailsHtml += `<div style="margin-top: 10px;"><strong>Parameters:</strong></div>`;
        for (const [key, value] of Object.entries(params)) {
            detailsHtml += `<div>&nbsp;&nbsp;${formatParamName(key)}: ${value}</div>`;
        }
    }
    
    details.innerHTML = detailsHtml;
    
    // Set up confirm button
    const confirmBtn = document.getElementById('confirmExecuteBtn');
    confirmBtn.onclick = () => {
        closeModal();
        startExecution(params);
    };
    
    if (script.dangerous) {
        confirmBtn.className = 'btn btn-danger';
        confirmBtn.textContent = '⚠️ Execute Anyway';
    } else {
        confirmBtn.className = 'btn btn-primary';
        confirmBtn.textContent = 'Execute';
    }
    
    modal.classList.remove('hidden');
}

function closeModal() {
    document.getElementById('confirmModal').classList.add('hidden');
}

async function startExecution(params = {}) {
    // Switch to execution panel
    showPanel('executionPanel');
    document.getElementById('pageTitle').textContent = 'Executing Script';
    updateBreadcrumb(['Home', state.registry[state.currentTier].name, 'Execution']);
    
    // Update execution title
    document.getElementById('executionTitle').textContent = 
        `Executing: ${state.currentScript.name}`;
    
    // Reset terminal
    clearTerminal();
    
    // Update status
    updateExecutionStatus('pending', 'Connecting...');
    
    // Disable/enable buttons
    document.getElementById('terminateBtn').disabled = false;
    document.getElementById('closeExecBtn').disabled = true;
    
    // Generate execution ID
    state.executionId = generateId();
    state.isExecuting = true;
    
    try {
        // Connect WebSocket
        await connectWebSocket(params);
    } catch (error) {
        console.error('Execution failed:', error);
        updateExecutionStatus('failed', `Error: ${error.message}`);
        document.getElementById('terminateBtn').disabled = true;
        document.getElementById('closeExecBtn').disabled = false;
        showToast('error', 'Execution failed to start');
    }
}

async function connectWebSocket(params) {
    const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${wsProtocol}//${window.location.host}/ws/${state.executionId}`;
    
    state.websocket = new WebSocket(wsUrl);
    
    state.websocket.onopen = () => {
        updateExecutionStatus('running', 'Starting execution...');
        appendToTerminal('Connecting to execution server...\n', 'info');
        
        // Send execution request
        state.websocket.send(JSON.stringify({
            action: 'execute',
            tier: state.currentTier,
            menu: state.currentMenu,
            script_id: state.currentScript.id,
            params: params,
            environment: {}
        }));
    };
    
    state.websocket.onmessage = (event) => {
        const data = JSON.parse(event.data);
        handleWebSocketMessage(data);
    };
    
    state.websocket.onerror = (error) => {
        console.error('WebSocket error:', error);
        appendToTerminal('\n[ERROR] WebSocket connection error\n', 'error');
    };
    
    state.websocket.onclose = () => {
        state.isExecuting = false;
        document.getElementById('terminateBtn').disabled = true;
        document.getElementById('closeExecBtn').disabled = false;
    };
}

function handleWebSocketMessage(data) {
    switch (data.type) {
        case 'output':
            appendToTerminal(data.content);
            break;
            
        case 'info':
            appendToTerminal(`[INFO] ${data.content}\n`, 'info');
            break;
            
        case 'success':
            appendToTerminal(`\n[SUCCESS] ${data.content}\n`, 'success');
            updateExecutionStatus('completed', data.content);
            showToast('success', 'Script completed successfully');
            break;
            
        case 'error':
            appendToTerminal(`\n[ERROR] ${data.content}\n`, 'error');
            updateExecutionStatus('failed', data.content);
            showToast('error', data.content);
            break;
            
        case 'prompt':
            showInputPrompt(data.content);
            break;
            
        case 'complete':
            const result = JSON.parse(data.content);
            state.logFile = result.html_log_file;
            state.isExecuting = false;
            document.getElementById('terminateBtn').disabled = true;
            document.getElementById('closeExecBtn').disabled = false;
            break;
            
        case 'terminated':
            appendToTerminal(`\n[TERMINATED] ${data.content}\n`, 'warning');
            updateExecutionStatus('failed', 'Execution terminated');
            break;
    }
}

function showInputPrompt(promptText) {
    const promptDiv = document.getElementById('inputPrompt');
    const promptMessage = document.getElementById('promptMessage');
    const promptInput = document.getElementById('promptInput');
    const suggestions = document.getElementById('promptSuggestions');
    
    promptMessage.textContent = promptText;
    promptInput.value = '';
    
    // Add quick response suggestions
    suggestions.innerHTML = '';
    
    // Detect common prompts and add appropriate suggestions
    if (promptText.toLowerCase().includes('y/n') || 
        promptText.toLowerCase().includes('continue')) {
        addSuggestion(suggestions, 'Y', 'Yes');
        addSuggestion(suggestions, 'N', 'No');
    } else if (promptText.toLowerCase().includes('option')) {
        // Menu options - add number suggestions
        for (let i = 1; i <= 5; i++) {
            addSuggestion(suggestions, i.toString(), `Option ${i}`);
        }
    }
    
    promptDiv.classList.remove('hidden');
    promptInput.focus();
    
    // Scroll terminal to show prompt
    const terminal = document.getElementById('terminalOutput');
    terminal.scrollTop = terminal.scrollHeight;
}

function addSuggestion(container, value, label) {
    const btn = document.createElement('button');
    btn.className = 'suggestion-btn';
    btn.textContent = label;
    btn.onclick = () => {
        document.getElementById('promptInput').value = value;
        sendPromptResponse();
    };
    container.appendChild(btn);
}

function handlePromptKeydown(event) {
    if (event.key === 'Enter') {
        sendPromptResponse();
    }
}

function sendPromptResponse() {
    const input = document.getElementById('promptInput');
    const response = input.value;
    
    if (state.websocket && state.websocket.readyState === WebSocket.OPEN) {
        state.websocket.send(JSON.stringify({
            action: 'input',
            text: response
        }));
        
        // Hide prompt
        document.getElementById('inputPrompt').classList.add('hidden');
        
        // Show response in terminal
        appendToTerminal(`\n> ${response}\n`, 'info');
    }
}

function terminateExecution() {
    if (state.websocket && state.websocket.readyState === WebSocket.OPEN) {
        state.websocket.send(JSON.stringify({
            action: 'terminate'
        }));
        
        showToast('warning', 'Terminating execution...');
    }
}

function closeExecution() {
    showPanel('scriptPanel');
    document.getElementById('pageTitle').textContent = 
        state.registry[state.currentTier].name;
    
    // Clean up
    if (state.websocket) {
        state.websocket.close();
        state.websocket = null;
    }
    state.isExecuting = false;
}

// ============================================================================
// Terminal Functions
// ============================================================================

function appendToTerminal(text, type = '') {
    const terminal = document.getElementById('terminalOutput');
    
    // Remove welcome message if present
    const welcome = terminal.querySelector('.terminal-welcome');
    if (welcome) {
        welcome.remove();
    }
    
    // Convert ANSI codes to HTML
    const html = ansiToHtml(text);
    
    const span = document.createElement('span');
    if (type) {
        span.className = type;
    }
    span.innerHTML = html;
    
    terminal.appendChild(span);
    state.outputBuffer.push(text);
    
    // Auto-scroll
    terminal.scrollTop = terminal.scrollHeight;
}

function clearTerminal() {
    const terminal = document.getElementById('terminalOutput');
    terminal.innerHTML = '<div class="terminal-welcome">Waiting for execution to start...</div>';
    state.outputBuffer = [];
}

function copyOutput() {
    const text = state.outputBuffer.join('');
    navigator.clipboard.writeText(text).then(() => {
        showToast('success', 'Output copied to clipboard');
    }).catch(() => {
        showToast('error', 'Failed to copy output');
    });
}

function downloadLog() {
    if (state.logFile) {
        window.open(`${API_BASE}/api/logs/${state.logFile.split('/').pop()}`, '_blank');
    } else {
        // Download current output
        const text = state.outputBuffer.join('');
        const blob = new Blob([text], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `execution_${state.executionId || 'output'}.log`;
        a.click();
        URL.revokeObjectURL(url);
    }
}

function updateExecutionStatus(status, text) {
    const statusDiv = document.getElementById('executionStatus');
    const indicator = statusDiv.querySelector('.status-indicator');
    const statusText = statusDiv.querySelector('.status-text');
    
    indicator.className = `status-indicator ${status}`;
    statusText.textContent = text;
}

// ============================================================================
// Logs Panel
// ============================================================================

async function showLogs() {
    showPanel('logsPanel');
    document.getElementById('pageTitle').textContent = 'Execution Logs';
    updateBreadcrumb(['Home', 'Logs']);
    await refreshLogs();
}

async function refreshLogs() {
    try {
        const response = await fetch(`${API_BASE}/api/logs?limit=50`);
        const logs = await response.json();
        
        const tbody = document.getElementById('logsTableBody');
        tbody.innerHTML = '';
        
        if (logs.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" style="text-align: center; color: var(--text-muted);">
                        No execution logs found
                    </td>
                </tr>
            `;
            return;
        }
        
        logs.forEach(log => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td class="filename">${log.filename}</td>
                <td class="size">${formatFileSize(log.size)}</td>
                <td class="date">${formatDate(log.modified)}</td>
                <td>
                    <div class="log-actions">
                        <button class="log-action-btn" onclick="viewLog('${log.filename}')">
                            View
                        </button>
                        <button class="log-action-btn" onclick="downloadLogFile('${log.filename}')">
                            Download
                        </button>
                    </div>
                </td>
            `;
            tbody.appendChild(row);
        });
        
    } catch (error) {
        console.error('Failed to load logs:', error);
        showToast('error', 'Failed to load logs');
    }
}

function viewLog(filename) {
    window.open(`${API_BASE}/api/logs/${filename}`, '_blank');
}

function downloadLogFile(filename) {
    window.location.href = `${API_BASE}/api/logs/${filename}`;
}

// ============================================================================
// Health Check
// ============================================================================

async function showHealth() {
    try {
        const response = await fetch(`${API_BASE}/api/health`);
        const health = await response.json();
        
        const message = `
Status: ${health.status}
Deployment Home: ${health.deployment_home}
Active Executions: ${health.active_executions}
        `.trim();
        
        showToast('info', message);
    } catch (error) {
        showToast('error', 'Health check failed');
    }
}

// ============================================================================
// Navigation Functions
// ============================================================================

function selectTier(tierId) {
    renderScriptPanel(tierId);
}

function goBack() {
    if (state.currentTier) {
        renderDashboard();
        state.currentTier = null;
        state.currentMenu = null;
    }
}

function showPanel(panelId) {
    document.querySelectorAll('.panel').forEach(panel => {
        panel.classList.add('hidden');
    });
    document.getElementById(panelId).classList.remove('hidden');
}

function updateBreadcrumb(items) {
    const breadcrumb = document.getElementById('breadcrumb');
    breadcrumb.innerHTML = items.map(item => `<span>${item}</span>`).join('');
}

// ============================================================================
// Utility Functions
// ============================================================================

function generateId() {
    return Math.random().toString(36).substring(2, 10);
}

function formatParamName(param) {
    return param
        .replace(/_/g, ' ')
        .replace(/\b\w/g, c => c.toUpperCase());
}

function formatFileSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

function formatDate(isoString) {
    const date = new Date(isoString);
    return date.toLocaleString();
}

function ansiToHtml(text) {
    // Basic ANSI to HTML conversion
    const ansiColors = {
        '30': '#374151', // Black
        '31': '#ef4444', // Red
        '32': '#10b981', // Green
        '33': '#f59e0b', // Yellow
        '34': '#3b82f6', // Blue
        '35': '#8b5cf6', // Magenta
        '36': '#00d4ff', // Cyan
        '37': '#e0e6ed', // White
    };
    
    let html = text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
    
    // Replace ANSI color codes
    html = html.replace(/\x1b\[(\d+)m/g, (match, code) => {
        if (code === '0') return '</span>';
        const color = ansiColors[code];
        if (color) return `<span style="color: ${color}">`;
        return '';
    });
    
    return html;
}

// ============================================================================
// Toast Notifications
// ============================================================================

function showToast(type, message) {
    const container = document.getElementById('toastContainer');
    
    const icons = {
        success: '✓',
        error: '✕',
        warning: '⚠',
        info: 'ℹ'
    };
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <span class="toast-icon">${icons[type]}</span>
        <span class="toast-message">${message}</span>
        <button class="toast-close" onclick="this.parentElement.remove()">×</button>
    `;
    
    container.appendChild(toast);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (toast.parentElement) {
            toast.style.animation = 'slideIn 0.3s ease reverse';
            setTimeout(() => toast.remove(), 300);
        }
    }, 5000);
}

// ============================================================================
// Keyboard Shortcuts
// ============================================================================

function setupKeyboardShortcuts() {
    document.addEventListener('keydown', (e) => {
        // Escape to close modals or go back
        if (e.key === 'Escape') {
            if (!document.getElementById('confirmModal').classList.contains('hidden')) {
                closeModal();
            } else if (!document.getElementById('paramModal').classList.contains('hidden')) {
                closeParamModal();
            } else if (!document.getElementById('scriptPanel').classList.contains('hidden')) {
                goBack();
            }
        }
        
        // Ctrl+L to view logs
        if (e.ctrlKey && e.key === 'l') {
            e.preventDefault();
            showLogs();
        }
        
        // Ctrl+H to go home
        if (e.ctrlKey && e.key === 'h') {
            e.preventDefault();
            renderDashboard();
        }
    });
}
