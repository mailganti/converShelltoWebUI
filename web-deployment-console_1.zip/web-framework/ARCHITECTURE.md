# Multi-Backend Proxy Architecture

## Overview

```
                                    ┌─────────────────────────────────────────────────────────────┐
                                    │                    SSL Proxy (port 8443)                    │
                                    │  ┌─────────────────────────────────────────────────────┐   │
    ┌──────────────┐               │  │              Authentication Layer                    │   │
    │              │  HTTPS/WSS    │  │  ┌────────────────┐    ┌──────────────────┐        │   │
    │   Browser    │──────────────▶│  │  │  Smart Card    │    │  NTLM/Kerberos   │        │   │
    │              │               │  │  │  (Primary)     │───▶│  (Fallback)      │        │   │
    └──────────────┘               │  │  └────────────────┘    └──────────────────┘        │   │
                                    │  └─────────────────────────────────────────────────────┘   │
                                    │                              │                              │
                                    │  ┌───────────────────────────▼───────────────────────────┐ │
                                    │  │                    Path Router                         │ │
                                    │  │                                                        │ │
                                    │  │  /deploy/*     ──▶  Deployment Console (8080)         │ │
                                    │  │  /api/v2/*     ──▶  API Backend (8001)                │ │
                                    │  │  /metrics/*    ──▶  Prometheus (9090)                 │ │
                                    │  │  /*            ──▶  Orchestration Dashboard (8000)    │ │
                                    │  │                                                        │ │
                                    │  └────────────────────────────────────────────────────────┘ │
                                    └─────────────────────────────────────────────────────────────┘
                                                               │
                    ┌──────────────────────────────────────────┼──────────────────────────────────────────┐
                    │                                          │                                          │
                    ▼                                          ▼                                          ▼
    ┌───────────────────────────┐          ┌───────────────────────────┐          ┌───────────────────────────┐
    │   Orchestration Dashboard │          │    Deployment Console     │          │      Other Services       │
    │        (port 8000)        │          │       (port 8080)         │          │                           │
    │                           │          │                           │          │  • API Backend (8001)     │
    │  ┌─────────────────────┐  │          │  ┌─────────────────────┐  │          │  • Prometheus (9090)      │
    │  │  FastAPI Backend    │  │          │  │  FastAPI Backend    │  │          │  • Static Files (8002)    │
    │  │  • Workflows        │  │          │  │  • Script Registry  │  │          │                           │
    │  │  • Agents           │  │          │  │  • Script Executor  │  │          └───────────────────────────┘
    │  │  • Approvals        │  │          │  │  • WebSocket Stream │  │
    │  │  • Tokens           │  │          │  │  • Log Management   │  │
    │  └─────────────────────┘  │          │  └─────────────────────┘  │
    │                           │          │                           │
    │  ┌─────────────────────┐  │          │  ┌─────────────────────┐  │
    │  │  Vanilla JS         │  │          │  │  Vanilla JS         │  │
    │  │  Frontend           │  │          │  │  Frontend           │  │
    │  └─────────────────────┘  │          │  └─────────────────────┘  │
    │                           │          │             │             │
    └───────────────────────────┘          │             │             │
                                           │             ▼             │
                                           │  ┌─────────────────────┐  │
                                           │  │   Shell Scripts     │  │
                                           │  │   • appTier/bin/*   │  │
                                           │  │   • dbTier/bin/*    │  │
                                           │  │   • common/bin/*    │  │
                                           │  └─────────────────────┘  │
                                           └───────────────────────────┘
```

## Request Flow

### 1. Smart Card Authentication (Primary)
```
Browser ──[TLS + Client Cert]──▶ Proxy ──[Extract DN]──▶ Validate ──▶ Backend
                                                              │
                                                              ▼
                                                    X-Authenticated-User: john.doe
                                                    X-Auth-Method: smartcard
                                                    X-User-CN: CN=john.doe@example.com
```

### 2. NTLM Authentication (Fallback)
```
Browser ──[HTTPS]──▶ Proxy ──[401 + WWW-Authenticate: NTLM]──▶ Browser
                        │
Browser ──[NTLM Type 1]──▶ Proxy ──[401 + NTLM Challenge]──▶ Browser
                        │
Browser ──[NTLM Type 3]──▶ Proxy ──[Validate]──▶ Backend
                                        │
                                        ▼
                              X-Authenticated-User: john.doe
                              X-Auth-Method: ntlm
                              X-User-Domain: MYDOMAIN
```

### 3. WebSocket Proxying (for Deployment Console)
```
Browser ──[Upgrade: websocket]──▶ Proxy ──[Forward Upgrade]──▶ Backend
                                    │                              │
                                    ◀──────[101 Switching]─────────┘
                                    │
                        ┌───────────┴───────────┐
                        │  Bidirectional Proxy  │
                        │  (Script Output)      │
                        └───────────────────────┘
```

## Port Assignments

| Service | Port | Path | Auth | WebSocket |
|---------|------|------|------|-----------|
| SSL Proxy | 8443 | / | - | Yes |
| Orchestration Dashboard | 8000 | / | Required | Yes |
| Deployment Console | 8080 | /deploy | Required | Yes |
| API Backend | 8001 | /api/v2 | Required | No |
| Prometheus | 9090 | /metrics | Optional | No |
| Static Files | 8002 | /static | No | No |

## Quick Start

### 1. Start the backends

```bash
# Terminal 1: Orchestration Dashboard (existing)
cd /path/to/orchestration
source venv/bin/activate
uvicorn main:app --port 8000

# Terminal 2: Deployment Console (new)
cd /path/to/web-framework
export DEPLOYMENT_HOME=/ADMIN/Oracle/Toolkits/deployStage
./run.sh start  # Runs on port 8080
```

### 2. Start the proxy

```bash
# Using default configuration
python ssl_proxy_multi.py

# Using custom configuration
python ssl_proxy_multi.py --config proxy-config.yaml

# Override port
python ssl_proxy_multi.py --port 443
```

### 3. Access the services

```
https://your-server:8443/              → Orchestration Dashboard
https://your-server:8443/deploy/       → Deployment Console
https://your-server:8443/api/v2/...    → API Backend
https://your-server:8443/metrics/      → Prometheus
```

## Adding New Backends

Edit `proxy-config.yaml`:

```yaml
backends:
  # Add new backend
  my-new-service:
    name: "My New Service"
    host: "localhost"
    port: 9000
    path_prefix: "/my-service"
    strip_prefix: true
    websocket: false
    auth_required: true
```

Restart the proxy:
```bash
python ssl_proxy_multi.py --config proxy-config.yaml
```

## Security Headers

The proxy adds these headers to backend requests:

| Header | Description | Example |
|--------|-------------|---------|
| `X-Authenticated-User` | Username | `john.doe` |
| `X-Auth-Method` | Authentication method | `smartcard` or `ntlm` |
| `X-User-Domain` | Windows domain | `MYDOMAIN` |
| `X-User-CN` | Certificate CN | `john.doe@example.com` |

## Backend Health Checks

The proxy performs periodic health checks on all backends:

```
[INFO] Backend health: orchestration=healthy, deploy-console=healthy, api=unhealthy
```

Unhealthy backends return 502 Bad Gateway to clients.

## Systemd Service

Create `/etc/systemd/system/ssl-proxy.service`:

```ini
[Unit]
Description=Multi-Backend SSL Proxy
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/ssl-proxy
ExecStart=/usr/bin/python3 ssl_proxy_multi.py --config proxy-config.yaml
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl daemon-reload
sudo systemctl enable ssl-proxy
sudo systemctl start ssl-proxy
```

## Troubleshooting

### Check proxy logs
```bash
tail -f /var/log/proxy/proxy.log
```

### Check access logs
```bash
tail -f /var/log/proxy/access.log
```

### Test backend connectivity
```bash
curl -v http://localhost:8080/api/health
curl -v http://localhost:8000/api/health
```

### Test through proxy
```bash
curl -k --cert client.crt --key client.key https://localhost:8443/api/health
```
