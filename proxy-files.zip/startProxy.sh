#!/bin/bash
# startProxy.sh - Start Multi-Backend SSL Proxy
#
# All configuration is in proxy-config.yaml - no need to edit this script

set -e  # Exit on error

# ============================================================
# CONFIGURATION
# ============================================================

# Base directory - set this or use environment variable
export BASE_DIR="${BASE_DIR:-/u01/app/ssaAgent/orchestration-system}"

# Config file location
CONFIG_FILE="$BASE_DIR/proxy/proxy-config.yaml"

# Log directory
LOG_DIR="$BASE_DIR/logs"

# Python executable (use virtual env if available)
if [ -f "$BASE_DIR/venv/bin/python" ]; then
    PYTHON="$BASE_DIR/venv/bin/python"
elif [ -f "$BASE_DIR/proxy/venv/bin/python" ]; then
    PYTHON="$BASE_DIR/proxy/venv/bin/python"
else
    PYTHON="python3"
fi

# Proxy script location
PROXY_SCRIPT="$BASE_DIR/proxy/ssl_proxy_multi.py"

# ============================================================
# FUNCTIONS
# ============================================================

check_requirements() {
    echo "[1/4] Checking requirements..."
    
    # Check Python
    if ! command -v $PYTHON &> /dev/null; then
        echo "❌ Python not found"
        exit 1
    fi
    echo "✓ Python: $($PYTHON --version)"
    
    # Check cryptography module
    if ! $PYTHON -c "from cryptography import x509" 2>/dev/null; then
        echo "❌ cryptography module not installed"
        echo "   Install with: pip install cryptography"
        exit 1
    fi
    echo "✓ cryptography module installed"
    
    # Check PyYAML
    if ! $PYTHON -c "import yaml" 2>/dev/null; then
        echo "❌ PyYAML not installed"
        echo "   Install with: pip install pyyaml"
        exit 1
    fi
    echo "✓ PyYAML installed"
    
    # Check config file
    if [ ! -f "$CONFIG_FILE" ]; then
        echo "❌ Config file not found: $CONFIG_FILE"
        exit 1
    fi
    echo "✓ Config file: $CONFIG_FILE"
    
    # Check proxy script
    if [ ! -f "$PROXY_SCRIPT" ]; then
        echo "❌ Proxy script not found: $PROXY_SCRIPT"
        exit 1
    fi
    echo "✓ Proxy script: $PROXY_SCRIPT"
    
    echo ""
}

check_certificates() {
    echo "[2/4] Checking SSL certificates..."
    
    # Extract cert paths from config (using Python to parse YAML)
    CERT_PATH=$($PYTHON -c "
import yaml
import os
with open('$CONFIG_FILE') as f:
    cfg = yaml.safe_load(f)
cert = cfg.get('ssl', {}).get('cert', '')
print(cert.replace('\${BASE_DIR}', os.environ.get('BASE_DIR', '')).replace('\$BASE_DIR', os.environ.get('BASE_DIR', '')))
")
    
    KEY_PATH=$($PYTHON -c "
import yaml
import os
with open('$CONFIG_FILE') as f:
    cfg = yaml.safe_load(f)
key = cfg.get('ssl', {}).get('key', '')
print(key.replace('\${BASE_DIR}', os.environ.get('BASE_DIR', '')).replace('\$BASE_DIR', os.environ.get('BASE_DIR', '')))
")
    
    CA_PATH=$($PYTHON -c "
import yaml
import os
with open('$CONFIG_FILE') as f:
    cfg = yaml.safe_load(f)
ca = cfg.get('ssl', {}).get('ca', '')
print(ca.replace('\${BASE_DIR}', os.environ.get('BASE_DIR', '')).replace('\$BASE_DIR', os.environ.get('BASE_DIR', '')))
")
    
    if [ ! -f "$CERT_PATH" ]; then
        echo "❌ Server certificate not found: $CERT_PATH"
        exit 1
    fi
    echo "✓ Server certificate: $CERT_PATH"
    
    if [ ! -f "$KEY_PATH" ]; then
        echo "❌ Server key not found: $KEY_PATH"
        exit 1
    fi
    echo "✓ Server key: $KEY_PATH"
    
    if [ ! -f "$CA_PATH" ]; then
        echo "⚠ CA certificate not found: $CA_PATH"
        echo "  Smart Card authentication may not work!"
    else
        echo "✓ CA certificate: $CA_PATH"
    fi
    
    echo ""
}

stop_old_processes() {
    echo "[3/4] Stopping old proxy processes..."
    
    pkill -f "python.*ssl_proxy" 2>/dev/null || true
    pkill -f "ssl_proxy_multi.py" 2>/dev/null || true
    
    sleep 2
    echo "✓ Old processes stopped"
    echo ""
}

start_proxy() {
    echo "[4/4] Starting proxy server..."
    
    # Ensure log directory exists
    mkdir -p "$LOG_DIR"
    
    # Extract server info from config for display
    SERVER_HOST=$($PYTHON -c "
import yaml
with open('$CONFIG_FILE') as f:
    cfg = yaml.safe_load(f)
print(cfg.get('server', {}).get('host', '0.0.0.0'))
")
    
    SERVER_PORT=$($PYTHON -c "
import yaml
with open('$CONFIG_FILE') as f:
    cfg = yaml.safe_load(f)
print(cfg.get('server', {}).get('port', 8443))
")
    
    echo ""
    echo "=========================================="
    echo "  Multi-Backend SSL Proxy"
    echo "=========================================="
    echo "Host: $SERVER_HOST"
    echo "Port: $SERVER_PORT"
    echo "Config: $CONFIG_FILE"
    echo "=========================================="
    echo ""
    echo "✓ Access at: https://$SERVER_HOST:$SERVER_PORT/"
    echo ""
    echo "⚠  Use HTTPS (not HTTP)!"
    echo ""
    echo "=========================================="
    echo ""
    
    # Start proxy
    echo "Starting server..."
    nohup $PYTHON "$PROXY_SCRIPT" --config "$CONFIG_FILE" >> "$LOG_DIR/proxy.log" 2>&1 &
    
    # Get PID
    PROXY_PID=$!
    echo $PROXY_PID > "$BASE_DIR/proxy/proxy.pid"
    
    sleep 2
    
    # Check if started successfully
    if ps -p $PROXY_PID > /dev/null 2>&1; then
        echo "✓ Proxy started (PID: $PROXY_PID)"
        echo "✓ Log file: $LOG_DIR/proxy.log"
    else
        echo "❌ Proxy failed to start. Check $LOG_DIR/proxy.log for errors"
        exit 1
    fi
}

show_status() {
    echo ""
    echo "=========================================="
    echo "  Proxy Status"
    echo "=========================================="
    
    if [ -f "$BASE_DIR/proxy/proxy.pid" ]; then
        PID=$(cat "$BASE_DIR/proxy/proxy.pid")
        if ps -p $PID > /dev/null 2>&1; then
            echo "Status: RUNNING (PID: $PID)"
        else
            echo "Status: STOPPED (stale PID file)"
        fi
    else
        if pgrep -f "ssl_proxy_multi.py" > /dev/null; then
            echo "Status: RUNNING (PID: $(pgrep -f ssl_proxy_multi.py))"
        else
            echo "Status: STOPPED"
        fi
    fi
    
    echo ""
    echo "Recent logs:"
    echo "------------"
    tail -10 "$LOG_DIR/proxy.log" 2>/dev/null || echo "No log file found"
    echo ""
}

stop_proxy() {
    echo "Stopping proxy..."
    
    if [ -f "$BASE_DIR/proxy/proxy.pid" ]; then
        PID=$(cat "$BASE_DIR/proxy/proxy.pid")
        kill $PID 2>/dev/null || true
        rm -f "$BASE_DIR/proxy/proxy.pid"
    fi
    
    pkill -f "ssl_proxy_multi.py" 2>/dev/null || true
    
    echo "✓ Proxy stopped"
}

# ============================================================
# MAIN
# ============================================================

case "${1:-start}" in
    start)
        echo "=========================================="
        echo "  Proxy Startup"
        echo "=========================================="
        echo "Base Directory: $BASE_DIR"
        echo ""
        
        check_requirements
        check_certificates
        stop_old_processes
        start_proxy
        ;;
    
    stop)
        stop_proxy
        ;;
    
    restart)
        stop_proxy
        sleep 2
        $0 start
        ;;
    
    status)
        show_status
        ;;
    
    logs)
        tail -f "$LOG_DIR/proxy.log"
        ;;
    
    *)
        echo "Usage: $0 {start|stop|restart|status|logs}"
        echo ""
        echo "Commands:"
        echo "  start   - Start the proxy server"
        echo "  stop    - Stop the proxy server"
        echo "  restart - Restart the proxy server"
        echo "  status  - Show proxy status and recent logs"
        echo "  logs    - Follow the proxy log file"
        exit 1
        ;;
esac
