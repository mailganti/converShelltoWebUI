# Oracle EBS Deployment Console

A web-enabled interface for executing Oracle EBS deployment scripts from the browser. This system wraps your existing shell script framework (appTier/bin, dbTier/bin) with a modern web interface featuring real-time output streaming, interactive prompt handling, and HTML logging.

## 🎯 Features

- **Modern Web Dashboard** - Dark navy/cyan themed interface matching your orchestration system
- **Real-time Output Streaming** - WebSocket-based live script output to browser
- **Interactive Prompt Handling** - Web-based responses to script prompts (Y/N, menu selections)
- **Dual Logging** - Both text and HTML formatted logs for every execution
- **Script Organization** - Organized by tier (appTier/dbTier) and category (Preserve/Restore/Configure)
- **Confirmation Dialogs** - Safety confirmations for destructive operations
- **Parameter Input** - Web forms for scripts requiring parameters
- **Remote Execution Support** - Handles scripts that run on secondary nodes

## 📁 Project Structure

```
web-framework/
├── backend/
│   └── main.py              # FastAPI backend with WebSocket support
├── frontend/
│   ├── index.html           # Main dashboard HTML
│   ├── css/
│   │   └── styles.css       # Dark theme styling
│   └── js/
│       └── app.js           # Vanilla JavaScript application
├── scripts/
│   └── web_wrapper.sh       # Wrapper for web-compatible execution
├── logs/                    # Execution logs (created at runtime)
├── requirements.txt         # Python dependencies
├── run.sh                   # Setup and run script
└── README.md               # This file
```

## 🚀 Quick Start

### 1. Prerequisites

- Python 3.8+
- Your existing shell script framework with `DEPLOYMENT_HOME` structure
- Network access to the server from your browser

### 2. Installation

```bash
# Clone/copy the web-framework to your server
cd /path/to/web-framework

# Make run script executable
chmod +x run.sh

# Setup the environment
./run.sh setup
```

### 3. Configuration

Set your deployment home:

```bash
export DEPLOYMENT_HOME=/ADMIN/Oracle/Toolkits/deployStage
```

### 4. Start the Server

Development mode (with auto-reload):
```bash
./run.sh start
```

Production mode:
```bash
./run.sh production
```

### 5. Access the Console

Open your browser and navigate to:
```
http://your-server:8080
```

## ⚙️ Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DEPLOYMENT_HOME` | (required) | Path to your deployment directory |
| `PORT` | 8080 | Server port |
| `HOST` | 0.0.0.0 | Server bind address |

### Script Registry

The script registry in `backend/main.py` defines all available scripts. Modify `SCRIPT_REGISTRY` to add/remove scripts:

```python
SCRIPT_REGISTRY = {
    "appTier": {
        "name": "Application Tier",
        "icon": "🖥️",
        "menus": {
            "preserve": {
                "name": "Preserve & Cleanup",
                "scripts": {
                    "PS": {
                        "name": "Presave Apps Configurations",
                        "script": "preSaveApps.sh",
                        "confirm": True  # Show confirmation dialog
                    },
                    # ... more scripts
                }
            }
        }
    }
}
```

### Script Options

| Option | Type | Description |
|--------|------|-------------|
| `name` | string | Display name |
| `script` | string | Script filename |
| `confirm` | bool | Require confirmation before execution |
| `dangerous` | bool | Mark as destructive (red styling + warning) |
| `remote` | bool | Executes on remote node |
| `params` | list | Required parameter names |

## 🔗 Integration with Existing Scripts

Your existing scripts work without modification. The web framework:

1. Sets up the environment (`DEPLOYMENT_HOME`, colors, etc.)
2. Sources `common/bin/commEnv` and tier-specific variable files
3. Executes scripts in a PTY for interactive support
4. Streams output via WebSocket
5. Handles prompts through the web interface

### Web-Aware Scripts (Optional)

For enhanced web integration, scripts can check for web execution:

```bash
if [[ "$WEB_EXECUTION" == "1" ]]; then
    echo "[WEB_INFO] Running in web mode"
    # Web-specific logic
fi
```

## 🔐 Security Considerations

### Authentication

This basic implementation doesn't include authentication. For production use, integrate with your existing auth system:

**Option 1: Proxy with OHS/Apache**
```apache
<Location /deploy-console>
    AuthType Basic
    AuthName "Deployment Console"
    # Your auth configuration
</Location>
```

**Option 2: Add FastAPI Security**
```python
from fastapi.security import HTTPBasic
# Add security middleware
```

**Option 3: Integrate with your SSL proxy**
The framework can sit behind your existing `ssl_proxy.py` with Smart Card/NTLM auth.

### Network Security

- Run behind a reverse proxy in production
- Use HTTPS (terminate at OHS/Apache)
- Restrict access to authorized hosts

## 📊 Logging

### Log Locations

- **Text logs**: `logs/*.log`
- **HTML logs**: `logs/*.html`
- **Access logs** (production): `logs/access.log`
- **Error logs** (production): `logs/error.log`

### Log Retention

Implement log rotation as needed:
```bash
find /path/to/logs -name "*.log" -mtime +30 -delete
```

## 🔧 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Main dashboard |
| `/api/registry` | GET | Get all available scripts |
| `/api/tier/{tier}` | GET | Get scripts for a tier |
| `/api/logs` | GET | List execution logs |
| `/api/logs/{filename}` | GET | View specific log |
| `/api/health` | GET | Health check |
| `/ws/{execution_id}` | WebSocket | Script execution stream |

## 🐛 Troubleshooting

### Script Not Found
Ensure the script exists in the correct tier directory:
```bash
ls $DEPLOYMENT_HOME/appTier/bin/
ls $DEPLOYMENT_HOME/dbTier/bin/
```

### Permission Denied
Check script permissions:
```bash
chmod +x $DEPLOYMENT_HOME/*/bin/*.sh
```

### WebSocket Connection Failed
- Check firewall rules for the port
- Ensure no proxy is stripping WebSocket upgrade headers

### Environment Not Loaded
Verify `commEnv` is accessible:
```bash
source $DEPLOYMENT_HOME/common/bin/commEnv
```

## 🔄 Extending the Framework

### Adding New Tiers

1. Add to `SCRIPT_REGISTRY` in `main.py`
2. Create corresponding directory structure
3. Add variable file if needed

### Custom Prompts

Handle custom prompts by extending the prompt detection:

```javascript
// In app.js - showInputPrompt()
if (promptText.includes('your-custom-prompt')) {
    addSuggestion(suggestions, 'option1', 'Option 1');
}
```

## 📝 License

Internal use - Oracle EBS Deployment Automation

## 🤝 Support

For issues or enhancements, contact the DBA automation team.
